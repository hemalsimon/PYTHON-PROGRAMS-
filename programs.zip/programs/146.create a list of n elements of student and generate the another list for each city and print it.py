#pr no 146
#29/06/2020
#create a list of n elements of student and generate the another list for each city and print it
def records(range_for_records):
    b=[]
    for i in range(range_for_records):
        a = []
        rollno = int(input("rollno "))
        name = (input("name "))
        age = int(input("age "))
        address = (input("address "))
        a.extend([rollno, name, age, address])
        b.append(a)
    return b
def cities(range_for_city):
    b=[]
    for i in range(range_for_city):
        x=input("give the cities")
        b.append(x)
    return b
def generatelist(recordlist,range_for_records,city_from_list):
    b=[]
    for i in range(range_for_records):
        if city_from_list in recordlist[i]:
            b.append(recordlist[i])
    return b
def printlist(printing):
    n=len(printing)
    for i in range(n):
        print(printing[i])
range_for_records=int(input("given the range "))
recordlist=records(range_for_records)
range_for_city=int(input("how many city do you want "))
citylist=cities(range_for_city)
length_of_the_citylist=len(citylist)
for i in range(length_of_the_citylist):
    city_from_list=citylist[i]
    printing=generatelist(recordlist,range_for_records,city_from_list)
    print(printing)

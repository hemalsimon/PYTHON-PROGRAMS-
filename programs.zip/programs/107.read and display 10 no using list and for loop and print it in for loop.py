# pr no 106
# 20/06/2020
# read and display 10 no using list and for loop and print it in for loop
b=[]
n=5
for i in range(n):
    a=[]
    x=int(input("x "))
    a.extend([x])
    b.append(a)
for i in range(n):
    print (b[i])
print(" ")
""" 
next for loop is another way of print the element by element
"""
for i in b:
    print(i)
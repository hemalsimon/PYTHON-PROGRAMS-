#pr no:64
#07/06/2020
#biggest and smallest of 10 numbers
big=small=b=int(input("enter the first no"))
i=1
while i<=10:
    a=int(input("enter the another no"))
    if a>big:
        big=a
    elif a<small:
        small=a
    i+=1
print ("big",big)
print("small",small)

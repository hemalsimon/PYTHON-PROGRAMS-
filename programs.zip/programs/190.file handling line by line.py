#pr no 190
#18/07/2020
#file handling
f=open("188.points.py","r")
r=f.readline()
print(r)
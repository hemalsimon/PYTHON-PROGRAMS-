#pr no 197
#20/07/2020
#convert the upper case to lower case
a=input("value of a ")
if 'A'<=a<='Z':
    c=ord(a)+32
    print(chr(c))

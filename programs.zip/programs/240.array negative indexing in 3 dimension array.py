import numpy as np
data=[1,2,3,4,5,6]
arr=np.array(data)
print(arr[-2])
#pr no 176
#11/07/2020
#matrix
import random
class matrix():
    def __init__(self,row=5,column=4):
        self._b=[]
        for i in range(row):
            self._a=[]
            for j in range(column):
                n=random.randint(-100,100)
                self._a.append(n)
            self._b.append(self._a)
    def print(self):
        for i in self._b:
                print(i)
"""
c=matrix()
c.print()
"""
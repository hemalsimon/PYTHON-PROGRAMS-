# pr.no:11
#30/05/2020
#given integer no is negative or not

a=int(input("value of a "))
if a<=0 :
    print ("negative")
else :
    print ("not negative")
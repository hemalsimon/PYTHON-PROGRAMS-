#pr no 54
#02/06/2020
#print the fibbonacci series using while loop
x=1
y=1
n=int(input("range"))
a=0
print(y)
while a<=n:
    a=x+y
    print(y)
    x=y
    y=a
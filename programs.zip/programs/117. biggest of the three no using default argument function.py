#pr.no:117
#22/06/2020
#biggest of three no using default argument function
def biggest(a=10,b=20,c=30):
    d=a if a>b else b
    e=d if d>c else c
    return e
x=int(input("x "))
y=int(input("y "))
z=int(input("z "))
o=biggest(x,y,z)
print(o)
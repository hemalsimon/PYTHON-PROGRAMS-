#pr no 138
#27/06/2020
#find the sum of two matrix
def readmatrix(n):
    b=[]
    for i in range(n):
        a=[]
        for j in range(n):
            x=int(input("x "))
            a.append(x)
        b.append(a)
    return b
def sumofthetwomatrix(x,y,n):
    sum=0
    b = []
    for i in range(n):
        a = []
        for j in range(n):
            sum=x[i][j]-y[i][j]
            a.append(sum)
        b.append(a)
    return b
def printmatirx(z,n):
    print("sum of the two matrix")
    for i in range(n):
        for j in range(n):
            print(z[i][j],end=' ')
        print(" ")
n=int(input("size of matrix "))
x=readmatrix(n)
y=readmatrix(n)
z=sumofthetwomatrix(x,y,n)
printmatirx(z,n)

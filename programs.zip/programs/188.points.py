#pr no 188
#17/07/2020
#points arthimetic, points relation
"""multi level inheritance"""
from point_arthimetic_operation186 import arthimetic_operators
from point_relational_operation187 import relational_operators
class points(arthimetic_operators,relational_operators):
    pass
#main
c=points()
d=points(50,100)
c.print()
d.print()
c.seta(10)
c.print()
c.setb(20)
c.print()
c.setab(30,60)
c.print()
d.seta(70)
d.print()
d.setb(80)
d.print()
d.setab(90,100)
d.print()
print(c.geta())
print(c.getb())
print(c.getab())
print(d.geta())
print(d.getb())
print(d.getab())
c.reset()
c.print()
d.reset()
d.print()
print(c)
print(d)
print("addition",c+d)
print("subraction",c-d)
print("multiplication",c*d)
print("less than\t\t\t",c<d)
print("greater than\t\t",c>d)
print("equal\t\t\t\t",c==d)
print("less than or equal\t\t",c<=d)
print("greator than or equal\t",c>=d)
print("not equal\t\t\t\t",c!=d)

#pr no 217
#23/07/2020
#segregate the jio,airtel,bsnl,telephone,no number
import re
f=open("details.py","r")
jio=[]
airtel=[]
bsnl=[]
telephone=[]
no_number=[]
while r:=f.readline():
    line=re.search(r'\d{9}',r)
    if (line):
        start=line.start()
        end=line.end()
        x=r[start:end]
        if x[0]=='6':
            jio.append(r)
        elif x[0]=='9':
            airtel.append(r)
        elif x[0]=='8':
            bsnl.append(r)
        elif x[0]=='0':
            telephone.append(r)
    else:
        no_number.append(r)
print("\njio user")
for i in jio:
    print(i,end='')
print("\nairtel user")
for i in airtel:
    print(i,end='')
print("\nbsnl user")
for i in bsnl:
    print(i,end='')
print("\ntelephone user")
for i in telephone:
    print(i,end='')
print("\nthey don't have no")
for i in no_number:
    print(i,end='')
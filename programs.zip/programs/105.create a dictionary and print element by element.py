#pr no 105
#19/06/2020
#create a dictionary and print element by element
b=[]
c={}
n=2
for i in range(n):
    a=[]
    rollno=int(input("rollno "))
    name=(input("name "))
    age=int(input("age"))
    address=(input("address"))
    a.extend([rollno,name,age,address])
    c[rollno]=a
d=c.keys()
print (d)
for i in d:
    print(c[i])

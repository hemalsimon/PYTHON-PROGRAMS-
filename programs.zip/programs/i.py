hii1 hello2.how are3 you4 man5.are you okay. what about your
family
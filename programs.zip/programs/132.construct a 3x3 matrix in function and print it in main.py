#pr no 132
#26/06/2020
#construct a 3x3 matrix in function and print it in main
def matrix():
    b=[]
    for i in range(3):
        a=[]
        for j in range(3):
            x=int(input("x "))
            a.append(x)
        b.append(a)
    return b
y=matrix()
print(y)

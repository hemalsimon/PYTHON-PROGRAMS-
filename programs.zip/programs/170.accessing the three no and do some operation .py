#pr no 170
#07/07/2020
#accessing the three no and do some operation
from accessing_three_no169 import child_accessing_three_no
class grandchild_operation_on_three_no(child_accessing_three_no):
    pass
    def sum(self):
        x=self.geta()+self.getb()+self.getc()
        return x
    def prod(self):
        x=self.geta()*self.getb()*self.getc()
        return x
    def big(self):
        x=self.geta() if self.geta()>self.getb() else self.getb()
        y=x if x>self.getc() else self.getc()
        return y
    def small(self):
        x = self.geta() if self.geta() < self.getb() else self.getb()
        y = x if x < self.getc() else self.getc()
        return y
e=grandchild_operation_on_three_no()
print("after set a")
e.seta(1000)
e.printvalues()
print("after set b")
e.setb(2000)
e.printvalues()
print("after set c")
e.setc(3000)
e.print()
print("")
print("after set a,b")
e.setab(101,202)
e.printvalues()
print("set a,b,c")
e.setabc(1002,2003,3004)
e.printvalues()
print("value of c",end=' ')
e.print()
e.reset()
print("value of c",end=' ')
e.print()
print("\nget a\t",e.geta())
print("get b\t",e.getb())
print("get c\t",e.getc())
print("get a,b\t",e.getab())
print("get a,b,c\t",e.getabc())
print("")
print("sum",e.sum())
print("product",e.prod())
print("big",e.big())
print("small",e.small())
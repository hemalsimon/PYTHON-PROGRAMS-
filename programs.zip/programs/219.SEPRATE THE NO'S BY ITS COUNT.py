import re
f=open("MAKE A LIST.py","r")
r=f.read()
z=r.split(',')
a=[]
x=0
a.append(x)
j=0
count=0
for i in z:
    while x:=len(a):
        if i==z[j]:
            count+=1
            a.extend(i)
            print(i,a)
        j+=1
# pr.no:02
    #30/05/2020
#area of the circle

r=10
c=3.14*r*r
print(c)
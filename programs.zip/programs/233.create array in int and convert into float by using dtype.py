import numpy as np
data=[[1,2,3],[4,5,6]]
con=np.array(data,dtype=float)
print(con)
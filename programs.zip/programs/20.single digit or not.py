# pr.no:20
#30/05/2020
#given integer no is single digit or not

a=int(input("value of a "))
if a>=-9 and a<=9:
    print("single")
else:
    print ("not a single")

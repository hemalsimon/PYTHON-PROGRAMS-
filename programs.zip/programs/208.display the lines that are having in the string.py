#pr no 207
#21/07/2020
#display the lines that are having in the string
sourcefile=input("source file ")
search=input("which one do you want to search ")
f=open(sourcefile,"r")
r=f.readline()
count=0
while len(r):
    if r.find(search)!=-1:
        count+=1
        print(count, "\t", r, end='')
    r=f.readline()
print("\nno of patterns occurs ",count)
#pr no 175
#09/07/2020
#sepration
from random_no_and_do_some_operation_using_protected174 import mathprogram
class sepration(mathprogram):
    def positivesep(self):
        print("that list ",self._a)
        self.__b=[]
        for i in self._a:
            if i>0:
                self.__b.append(i)
        return self.__b
    def negativesep(self):
        self.__b=[]
        for i in self._a:
            if i<0:
                self.__b.append(i)
        return self.__b
    def first_half(self):
        n=len(self._a)
        m=int(n/2)
        self.__b=[]
        for i in range(m):
            self.__b.append(self._a[i])
        return self.__b
    def secondhalf(self):
        n=len(self._a)
        m=int(n/2)
        self.__b=[]
        while m!=n:
            self.__b.append(self._a[m])
            m+=1
        return self.__b
    def middle(self):
        n=len(self._a)
        i=3
        self.__b=[]
        j=n-2
        while i!=j:
            self.__b.append(self._a[i])
            i+=1
        return self.__b
c=sepration()
c.printrandom()
print("\n")
print("positive count ",c.poscount())
print("negative count ",c.negcount())
print("positive sum ",c.possum())
print("negative sum ",c.negsum())
print("biggest no ",c.biggest())
print("smallest no ",c.smallest())
print("no of even ",c.noeven())
print("no of odd ",c.noodd())
print("\n")
print("positive list",c.positivesep())
print("negative list",c.negativesep())
print("first half",c.first_half())
print("second half",c.secondhalf())
print("middle",c.middle())
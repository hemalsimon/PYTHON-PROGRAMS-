#pr.no:118
#22/06/2020
#create a list in function
def list():
    b=[]
    x=int(input("x "))
    b.append(x)
    return b
z=list()
print(z)
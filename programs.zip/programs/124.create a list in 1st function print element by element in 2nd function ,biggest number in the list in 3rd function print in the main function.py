#pr.no:124
#22/06/2020
#create a list in 1st function
# print element by element in 2nd function ,
# biggest number in the list in 3rd function
# print in the main function
def readlist():
    b=[]
    x=int(input("x "))
    while x!=1000:
        b.append(x)
        x=int(input("x "))
    return b
def printlist(a):
    for i in a:
        print(i)
def biggest(b):
    big=b[0]
    for i in b:
        if i>big:
            big=i
    return big
z=readlist()
printlist(z)
y=biggest(z)
print("biggest",y)

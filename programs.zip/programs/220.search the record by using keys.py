#pr no 220
#25/07/2020
#search the record by using keys
import re
file=input("give the dno ")
empty_dict = {'cs': None, 'ch': None,'ps':None,'ma':None}
search=re.search(r'\d{2}[a-z|A-Z]{3}\d{3}',file)
start=search.start()
end=search.end()
place=file[start:end]
if z:=place[3]+place[4] in empty_dict.keys() and place[2]==('u','U','P','p'):
    if x:=place[0]+place[1]=='16' :
        print("batch = 2016")
    elif x:=place[0]+place[1]=='17' :
        print("batch = 2017")
    if place[2]==('u'or'U'):
        print("UG/PG = UG")
    elif place[2]==('p'or'P'):
        print("UG/PG = PG")
    if z:=place[3]+place[4]==('cs'or'CS'):
        print("department = computer science")
    elif z:=place[3]+place[4]==('ph'or'PH'):
        print("department = physics")
    elif z:=place[3]+place[4]==('ch'or'CH'):
        print("department = chemistry")
    elif z:=place[3]+place[4]==('ma'or'MA'):
        print("department = maths")
    print("rollno =", c := place[5] + place[6] + place[7])
else:
    print("not")

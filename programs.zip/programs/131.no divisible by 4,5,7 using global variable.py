#pr no 131
#26/06/2020
#no of divisible by 4,5,7 using global variable
divisible_by_four=0
divisible_by_five=0
divisible_by_seven=0
def readlist():
    b=[]
    x=int(input("x "))
    while x!=1000:
        b.append(x)
        x=int(input("x "))
    return b
def printlist(a):
    for i in a:
        print(i)
def divisible(b):
    n=len(b)
    global divisible_by_four,divisible_by_five,divisible_by_seven
    for i in range(n):
        if b[i]%4==0:
            divisible_by_four+=1
        elif b[i]%5==0:
            divisible_by_five+=1
        elif b[i]%7==0:
            divisible_by_seven+=1
y=readlist()
printlist(y)
divisible(y)
print ("divisible_by_four",divisible_by_four)
print("divisible_by_five",divisible_by_five)
print("divisible_by_seven",divisible_by_seven)


#pr.no:126
#24/06/2020
#interchange the biggest and smallest no using function
def readlist():
    b=[]
    x=int(input("x "))
    while x!=1000:
        b.append(x)
        x=int(input("x "))
    return b
def printlist(a):
    for i in a:
        print(i)
def bigindex(b):
    big=b[0]
    index=0
    n=len(b)
    for i in range(n):
        if b[i]>big:
            big=b[i]
            index=i
    print("big\n",big)
    print("bigindex\n",index)
    return index
def smallindex(b):
    small=b[0]
    index=0
    n=len(b)
    for i in range(n):
        if b[i]<small:
            small=b[i]
            index=i
    print("small\n",small)
    print("smallindex\n",index)
    return index
def interchange(a):
    print(a)
    m=bigindex(a)
    n=smallindex(a)
    z=a[m]
    a[m]=a[n]
    a[n]=z
    return a

y=readlist()
printlist(y)
e=interchange(y)
print (e)

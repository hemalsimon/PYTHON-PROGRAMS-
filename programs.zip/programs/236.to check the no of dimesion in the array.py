import numpy as np
data=(1,2,3,4,5)
dim=np.array(data,dtype=int,ndmin=3)
print(dim)
print("no of dimesion",dim.ndim)
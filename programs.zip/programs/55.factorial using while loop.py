#pr no 55
#02/06/2020
#factroial using while loop
n=int(input("enter"))
f=1
i=1
while i<=n:
    f=f*i
    i+=1
print(f)
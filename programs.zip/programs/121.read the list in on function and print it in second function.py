#pr.no:121
#22/06/2020
#read the list in function and print it in second function
def readlist():
    b=[]
    for i in range(10):
        x=int(input("x "))
        b.append(x)
    return b
def printlist():
    z=readlist()
    for i in range(10):
        print (z[i])
printlist()

# pr.no:16
#30/05/2020
#given integer no is biggest of three

a=int(input("value of a "))
b=int(input("value of b "))
c=int(input("value of c "))
if a>b:
    if a>c :
        print("a is big")
    else:
        print ("c is big")
elif b>c:
    print(" b is big")
else:
    print("c is big")
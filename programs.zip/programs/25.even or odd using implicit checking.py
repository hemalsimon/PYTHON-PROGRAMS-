# pr.no:25
#30/05/2020
#given integer no is even or odd using implicit checking

a=int(input("value of a "))
c=a%2
if (c):
    print("odd")
else:
    print ("even")

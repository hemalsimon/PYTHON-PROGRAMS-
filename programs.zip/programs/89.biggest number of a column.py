#pr no 89
#15/06/2020
#biggest no of a column
b=[]
i=0
while i<3:
    a=[]
    j=0
    while j<3:
        x=int(input("value of x"))
        a.append(x)
        j+=1
    b.append(a)
    i+=1
column=int(input("column"))
i=0
big=0
while i<3:
    if b[i][column]>big:
        big=b[i][column]
    i+=1
print(big)
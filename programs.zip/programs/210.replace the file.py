# pr no 207
# 21/07/2020
# display the lines that are having in the string
sourcefile = input("source file ")
string1=input("replace old ")
string2=input("replace new ")
destinationfile=input("destinationfile ")
f = open(sourcefile, "r")
r = f.readline()
c=open(destinationfile,"w")
while len(r):
    change=r.replace(string1,string2)
    p=c.write(change)
    r = f.readline()
f.close()
c.close()
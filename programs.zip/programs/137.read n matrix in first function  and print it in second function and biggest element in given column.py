#pr no 137
#27/06/2020
#read n matrix in first function and print it in second function and biggest element in given column
def readmatrix(n):
    b=[]
    for i in range(n):
        a=[]
        for j in range(n):
            x=int(input("x "))
            a.extend([x])
        b.append(a)
    return b
def printmatirx(y,n):
    for i in range(n):
        for j in range(n):
           print(y[i][j],end=' ')
        print(" ")
def biggestelementincolumn(y,n,column):
    big=0
    for i in range(n):
        if(y[i][column]>big):
            big=y[i][column]
    return big
n=int(input("size of matrix "))
y=readmatrix(n)
printmatirx(y,n)
column=(int(input("give the column ")))
print("biggest element in given column",biggestelementincolumn(y,n,column))
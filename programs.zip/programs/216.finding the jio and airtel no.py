#pr no 216
#23/07/2020
#find the jio and airtel no
import re
f=open("details.py","r")
while r:=f.readline():
    s=re.search(r'\d{9}',r)
    print(s)
    print(s.start())
    print(s.end())
'''
    print(t)
    print(s)
    x=r[28:37]
    if(x[0]=='6'):
        print(r)
'''
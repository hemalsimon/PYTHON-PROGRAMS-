#pr no 33
#01/06/2020
#biggest of the three integer no not using if
a=int(input ("value of a"))
b=int(input ("value of b"))
c=int(input ("value of c"))
d=a if a>b else b
f=d if d>c else c
print(f)
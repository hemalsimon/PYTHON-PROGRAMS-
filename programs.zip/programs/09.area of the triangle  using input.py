# pr.no:09
#30/05/2020
#area of the triangle

b=int(input("value of b "))
h=int(input("value of h "))
c=1/2*b*h
print(c)
#pr no:65
#07/06/2020
#create a list of 10 elements and print it
a=[]
i=0
while i<=10:
    x=int(input("value of x  "))
    a.append(x)
    i+=1
print(a)
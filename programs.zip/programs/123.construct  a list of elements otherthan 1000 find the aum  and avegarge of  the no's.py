#pr.no:123
#22/06/2020
#construct a list of elements other than 1000
# from the 1st function,
# 2nd function print element by element ,
# 3rd function sum of the element and average of the elements
def readlist():
    b=[]
    x=int(input("x "))
    while x!=1000:
        b.append(x)
        x=int(input("x "))
    return b
def printlist(a):
    for i in a:
        print(i)
def sum(b):
    sum=0
    for i in b:
        sum=sum+i
    print("sum=",sum)
    return sum
y=readlist()
printlist(y)
z=sum(y)
n=len(y)
average=z/n
print("average",average)
#pr no 188
#17/07/2020
#points arthimetic, points relation
"""multi level inheritance"""
from point_arthimetic_operation186 import arthimetic_operators
from point_relational_operation187 import relational_operators
class points(arthimetic_operators,relational_operators):
    pass
#main
c=points()
d=points(50,100)
c.point()
d.point()
c.seta(10)
c.point()
c.setb(20)
c.point()
c.setab(30,60)
c.point()
d.seta(70)
d.point()
d.setb(80)
d.point()
d.setab(90,100)
d.point()
point(c.geta())
point(c.getb())
point(c.getab())
point(d.geta())
point(d.getb())
point(d.getab())
c.reset()
c.point()
d.reset()
d.point()
point(c)
point(d)
point("addition",c+d)
point("subraction",c-d)
point("multiplication",c*d)
point("less than\t\t\t",c<d)
point("greater than\t\t",c>d)
point("equal\t\t\t\t",c==d)
point("less than or equal\t\t",c<=d)
point("greator than or equal\t",c>=d)
point("not equal\t\t\t\t",c!=d)

#pr no 154
#01/07/2020
#sum of the two interger no using constructor in object oriented programming
class sum_of_the_two_no:
    _x=None
    _y=None
    _sum=None
    def __init__(self):
        self._x=10
        self._y=20
    def findsum(self):
        self._sum=self._x+self._y
    def printsum(self):
        print("sum of the two no is ",self._sum)
a=sum_of_the_two_no()
a.findsum()
a.printsum()
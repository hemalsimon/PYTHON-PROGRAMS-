#pr no 91
#15/06/2020
#construct list of n students record and print it one by one
b=[]
i=0
n=5
while i<n:
    a=[]
    rollno=int(input("roll no "))
    name=(input("name "))
    age=int(input("age"))
    address=(input("address"))
    a.extend([rollno,name,age,address])
    b.append(a)
    print(i)
    i+=1
n=len(b)
i=0
while i<n:
    print(b[i])
    i+=1

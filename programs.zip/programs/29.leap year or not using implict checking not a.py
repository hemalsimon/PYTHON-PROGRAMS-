# pr.no:26
#01/06/2020
#given integer no is leap year or not using implicit checking not c

a=int(input("value of a "))
c=a%4
if (not c):
    print("leap year")
else:
    print("not leap year ")

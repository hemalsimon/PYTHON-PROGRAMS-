#pr no 198
#20/07/2020
#convert the lower case to upper case
a=input("value of a ")
if 'a'<=a<='z':
    c=ord(a)-32
    print(chr(c))

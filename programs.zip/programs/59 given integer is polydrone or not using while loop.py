#pr no 59
#04/06/2020
#given integer is polydrone or not using while loop
q=int(input("value of q   "))
x=q
r=1
s=""
while q!=0:
    r=q%10
    q=int(q/10)
    s=s+str(r)
i=int(s)
print(q)
print(s)
print(i)
if x==i:
    print("polydrone")
else:
    print("not ploydrone")
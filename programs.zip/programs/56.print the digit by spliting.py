#pr no 56
#02/06/2020
#print the digit by split and print using while loop
q=int(input("value of n"))
r=1
while q!=0:
    r=q%10
    q = int (q / 10)
    print(r)

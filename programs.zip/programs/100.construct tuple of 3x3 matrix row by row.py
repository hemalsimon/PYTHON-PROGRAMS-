#pr no 101
#19/06/2020
#construct a tuple of 3 x 3 matrix print row by row
b=[]
i=0
while i<3:
    a=[]
    j=0
    while j<3:
        x=int(input("x "))
        a.extend([x])
        j+=1
    b.append(a)
    i+=1
i=0
c=tuple(b)
n=len(c)
while i<n:
    print (c[i])
    i+=1

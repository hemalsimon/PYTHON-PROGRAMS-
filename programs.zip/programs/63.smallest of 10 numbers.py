#pr no 63
#05/06/2020
#smallest of 10 numbers using while loop
b=int(input("value of b"))
i=1
while i<=10:
    a=int(input("enter the another no"))
    if a<b:
        b=a
    i+=1
print(b)

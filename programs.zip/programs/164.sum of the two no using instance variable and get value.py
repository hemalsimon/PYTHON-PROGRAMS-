#pr no :163
#03/07/2020
#sum of the two no using instance variable and get value
#pr no 161
#03/07/2020
#sum of the two no using instance variable
class sum_of_the_two_no():
    __a=None
    __b=None
    __sum=None
    def __init__(self,x=100,y=300):
        self.__a=x
        self.__b=y
    def setx(self,x):
        self.__a=x
        print("set x",end='\t')
    def sety(self,y):
        self.__b=y
        print("set y",end='\t')
    def setxy(self,x,y):
        self.__a=x
        self.__b=y
        print("set x,set y",end='\t\t')
    def reset(self):
        self.__init__()
    def geta(self):
        return self.__a
    def getb(self):
        return self.__b
    def getab(self):
        return self.__a,self.__b
    def getsum(self):
        return self.__sum
    def findsum(self):
        self.__sum=self.__a+self.__b
    def printsum(self):
        print("sum of the two no\t",self.__sum)
c=sum_of_the_two_no()
c.findsum()
c.printsum()
c.setx(300)
c.findsum()
c.printsum()
c.sety(400)
c.findsum()
c.printsum()
c.setxy(400,500)
c.findsum()
c.printsum()
c.reset()
c.findsum()
c.printsum()
print("a value\t ",c.geta())
print("b value\t ",c.getb())
print("a,b value\t",c.getab())
print("sum value\t",c.getsum())
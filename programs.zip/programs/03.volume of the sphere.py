# pr.no:03
#30/05/2020
#volume of the sphere

r=int(input("Enter The Radius : "))
c=4/3*3.14*r*r*r
print(c)
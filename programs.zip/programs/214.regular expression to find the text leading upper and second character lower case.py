import re
s="Ram 22 Hemal 23 Simon 6559 NHYZ 545659 KisHOore 654654 RanjiTh 54646565"
z=re.findall('[A-Z][a-z]',s)
x=re.findall('[A-Z]+[a-z]+',s)
y=re.findall('[A-Z][a-z]*',s)
print(s)
print("without any",z)
print("plus",x)
print("cross",y)
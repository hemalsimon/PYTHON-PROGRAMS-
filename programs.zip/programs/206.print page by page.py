#pr no 206
#21/07/2020
#print page by page
source=input("source ")
f=open(source,"r")
r=f.readline()
line=0
while len(r):
    line=line+1
    print(line,end='\t')
    print(r,end='')
    if line%20==0:
        a=input()
    r=f.readline()
#pr no :183
#14/07/2020
#read and display the points using read method
class points():
    __x=None
    __y=None
    def __init__(self,x=10,y=20):
        self.__x=x
        self.__y=y
    def __del__(self):
        print("deleted")
    def __str__(self):
        return "({0},{1})".format(self.__x,self.__y)
    def read(self):
        self.__x=int(input("value of x"))
        self.__y=int(input("value of y"))
    def print(self):
        print(self.__x)
        print(self.__y)
c=points()
c.print()
c.read()
c.print()
print(c)

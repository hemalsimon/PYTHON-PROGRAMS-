#pr no 101
#19/06/2020
#create a n students of tuples
b=[]
i=0
n=3
while i<n:
    a=[]
    rollno=int(input("roll no "))
    name=(input("name "))
    age=int(input("age"))
    address=(input("address"))
    a.extend([rollno,name,age,address])
    b.append(a)
    print(i)
    i+=1
c=tuple(b)
i=0
while i<n:
    print (c[i])
    i+=1
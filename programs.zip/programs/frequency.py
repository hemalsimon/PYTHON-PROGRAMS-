This this in-built function of Python helps to pop out elements
from a setjust like the principal used in the concept while
implementing Stack. This method removes a random element
from the set and returns the removed element. Unlike, a
stack a random element is popped off the set.
#pr no 93
#18/06/2020
#construct a list of n students display the student who is living in trichy and age is above 21 to 25
b=[]
i=0
print("hi")
while i<2:
    print("hi")
    a=[]
    rollno=int(input("rollno "))
    name=(input("name "))
    age=int(input("age "))
    address=input("address")
    a.extend([rollno,name,age,address])
    b.append(a)
    i+=1
n=len(b)
i=0
while i<n:
    print(b[i])
    i+=1
i=0
c=[]

while i<n:

    if b[i][3]=="trichy":
        print(n)
        if b[i][2]>=21 and b[i][2]<=25:
            c.append(b[i][1])
            print(c)
    i+=1
print(c)


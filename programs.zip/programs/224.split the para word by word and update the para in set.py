#pr no 224
#29/07/2020
#split the para word by word and update the para in set
txt="he is a boy. he have have three elder brother"
print(txt)
set1=set()
split=txt.split()
set1.update(split)
print(set1)
'''set1=set()
set2=set()
set3=set()
split=txt.split()
set1.update(split)
print(set1)
s=set1.pop()
print(s)
p=txt.count(s)
print(p)
set2.add(s)
print(set2)'''

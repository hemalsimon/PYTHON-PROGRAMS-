#pr no 35
#01/06/2020
#print the number 1 to 100 using while loop
i=1
while i<=100:
    print(i)
    i+=1
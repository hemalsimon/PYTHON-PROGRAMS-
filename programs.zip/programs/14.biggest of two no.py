# pr.no:14
#30/05/2020
#given integer no is biggest of two

a=int(input("value of a "))
b=int(input("value of b "))
if a>b:
    print("a is big")
else:
    print("b is big")
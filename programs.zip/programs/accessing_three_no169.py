#pr no 169
#06/07/2020
#accessing the last program from this program

from accessing_two_values166 import accessing_two_no
class child_accessing_three_no(accessing_two_no):
    pass
    __c=None
    def __init__(self,a=1001,b=2002,c=3003):
        accessing_two_no.__init__(self,a,b)
        self.__c=c
    def setc(self,c):
        self.__c=c
    def setabc(self,a,b,c):
        accessing_two_no.setab(self,a,b)
        self.__c=c
    def getc(self):
        return self.__c
    def getabc(self):
        return self.geta(),self.getb(),self.__c
    def reset(self):
        self.__init__()
    def print(self):
        print(self.__c)
"""
d=child_accessing_three_no()
print("after set a")
d.seta(1000)
d.printvalues()
print("after set b")
d.setb(2000)
d.printvalues()
print("after set c")
d.setc(3000)
d.print()
print("")
print("after set a,b")
d.setab(101,202)
d.printvalues()
print("set a,b,c")
d.setabc(1002,2003,3004)
d.printvalues()
print("value of c",end=' ')
d.print()
d.reset()
print("value of c",end=' ')
d.print()
print("\nget a\t",d.geta())
print("get b\t",d.getb())
print("get c\t",d.getc())
print("get a,b\t",d.getab())
print("get a,b,c\t",d.getabc())
"""
#pr no 193
#20/07/2020
#simple program given no is single, two, three, four digit or not
a=int(input("value of a "))
if 0<=a<=9:
    print("single digit")
elif 10<=a<=99:
    print("two digit")
elif 100<=a<=999:
    print("three digit")
elif 1000<=a<=9999:
    print("four digit")
else :
    print("given no is above four digit")
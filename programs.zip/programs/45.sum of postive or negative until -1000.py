#pr no 45
#01/06/2020
# count positive negative zero read and display until -1000
b=0
c=0
d=0
a=int(input("value of a"))
while(a!=-1000):
    if(a>0):
        b=b+a
    elif(a<0):
        c=c+a
    else:
        d=d+a
    print(b)
    print(c)
    print(d)
    print(a)
    a = int(input("value of a"))


#pr no 199
#20/07/2020
#file handling the split
source=input("source file ")
f=open(source,"r")
r=f.read()
print(r)
print(r.split())
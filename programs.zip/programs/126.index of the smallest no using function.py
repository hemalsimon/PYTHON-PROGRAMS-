#pr.no:124
#22/06/2020
#index of the smallest no using function
# index of the biggest no
def readlist():
    b=[]
    x=int(input("x "))
    while x!=1000:
        b.append(x)
        x=int(input("x "))
    return b
def printlist(a):
    for i in a:
        print(i)
def smallest(b):
    small=b[0]
    index=0
    n=len(b)
    for i in range(n):
        if b[i]<small:
            small=b[i]
            index=i
    print("small",small)
    return index
z=readlist()
printlist(z)
y=smallest(z)
print("index",y)

#pr no 103
#19/06/2020
#create a dictionary for a student
b=[]
a={}
rollno=int(input("rollno "))
name=(input("name "))
age=int(input("age"))
address=(input("address"))
b.extend([rollno,name,age,address])
a[rollno]=b
print (a)
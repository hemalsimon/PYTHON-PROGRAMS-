#pr no 171
#08/07/2020
#generate the random no
import random
class mathprogram():
    def getrandom(self):
        self.__a=[]
        for i in range(10):
            n=random.randint(-100,100)
            self.__a.append(n)
    def printrandom(self):
        for i in self.__a:
            print(i)
c=mathprogram()
c.getrandom()
c.printrandom()
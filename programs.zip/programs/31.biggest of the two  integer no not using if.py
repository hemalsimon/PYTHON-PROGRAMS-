#pr no 31
#01/06/2020
#biggest of the three integer no not using if
a=int (input ("value of a"))
b=int (input ("value of b"))
c=a if a>b else b
print(c)
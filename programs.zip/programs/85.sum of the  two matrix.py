#pr no 85
#12/06/2020
#sum of the two matrix
b=[]
i=0
while i<3:
    a=[]
    j=0
    while j<3:
        x=int(input("value of x"))
        a.append(x)
        j+=1
    b.append(a)
    i+=1
d=[]
i=0
while i<3:
    c=[]
    j=0
    while j<3:
        x=int(input("value of x"))
        c.append(x)
        j+=1
    d.append(c)
    i+=1
i=0
f=[]
while i<3:
    j=0
    e=[]
    while j<3:
        n=0
        n=b[i][j]+d[i][j]
        e.append(n)
        j+=1
    f.append(e)
    i+=1
i=0
while i<3:
    j=0
    while j<3:
        print(f[i][j],end=' ')
        j+=1
    i+=1
    print("")

#pr no 34
#01/06/2020
#smallest of the three integer no not using if
a=int(input("value of a"))
b=int(input("value of b"))
c=int(input("value of c"))
d= a if a<b else b
e= d if d<c else c
print(e)
#pr no 204
#21/07/2020
#read line by line
source=input("source ")
f=open(source,"r")
r=f.readline()
while len(r):
    print(r,end='')
    r=f.readline()
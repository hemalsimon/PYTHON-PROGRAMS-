#pr no 199
#20/07/2020
#split and count the text
text=input("text ")
s=text.split()
print(s)
print(len(s))
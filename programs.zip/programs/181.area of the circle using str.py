#pr no 155
#01/07/2020
#area of the circle using constructor in oop
class area_of_the_circle():
    __r=None
    __area=None
    def __init__(self):
        self.__r=10
    def __str__(self):
        return "({0},{1})".format(self.__r,self.__area)
    def findarea(self):
        self.__area=3.14*self.__r**2
    def printarea(self):
        print("area of the circle",self.__area)
a=area_of_the_circle()
print(a)
a.findarea()
print(a)
a.printarea()
#pr.no:118
#22/06/2020
#create a list in function get the input in main
def list(a):
    b=[]
    b.append(a)
    return b
x=int(input("x "))
z=list(x)
print(z)
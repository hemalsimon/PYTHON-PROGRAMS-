#pr no 83
#12/06/2020
#read the  3 x 3 matrix print it element by element

b=[]
i=0
while i<3:
    a = []
    j=0
    while j<3:
        x=int(input("value of x"))
        a.append(x)
        j+=1
    b.append(a)
    i+=1
i=0
while i<3:
    j=0
    while j<3:
        print(b[i][j],end=' ')
        j+=1
    print(" ")
    i += 1

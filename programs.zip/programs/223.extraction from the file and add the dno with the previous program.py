#pr no 223
#26/07/2020
#extracton from the file  name,age,city,pincode,phno,clg
import re
file=open("name,age,city,pincode,phno,mail.py","r")
d={}
d['name']=r'^[A-Z][a-z]+'
d['age']=r'\d{2}'
d['pincode']=r'\d{6}'
d['ph_no']=r'\d{10}'
d['mail']=r'[a-z]+[.a-z]+@[a-z]+.[a-z]+'
d['d_no']=r'\d{2}[a-z|A-Z]{3}\d{3}'
while r:=file.readline():
    name=re.search(d['name'],r)
    age=re.search(d['age'],r)
    pincode=re.search(d['pincode'],r)
    ph_no=re.search(d['ph_no'],r)
    mail=re.search(d['mail'],r)
    d_no=re.search(d['d_no'],r)
    print("name\t",n:=name.group())
    print("age\t\t",a:=age.group())
    print("pincode\t",pi:=pincode.group())
    print("ph_no\t",p:=ph_no.group())
    print("mail\t",m:=mail.group())
    print("d_no\t",dno:=d_no.group())
    set1=set()
    set1.update([n,a,pi,p,m,dno])
    set2=set()
    split=r.split()
    set2.update(split)
    setfinal=set1^set2
    setf=setfinal.pop()
    print("city\t",setf)
    print("\n")

16ubc528    hemon       22  dindigul    BCA
16upc528    helsimon    22  dindigul    BCA
16ucc528    malsimon    22  dindigul    BCA
16ucc527    simon       22  dindigul    BCA
16upc526    hemal       22  dindigul    BCA
16ubc525    hemsimon    22  dindigul    BCA

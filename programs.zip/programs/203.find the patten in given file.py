#pr no 202
#21/07/2020
#read and display the excel sheet
source=input("source file ")
f=open(source,"r")
r=f.read()
x=r.find('print')
print(r)
print(x)
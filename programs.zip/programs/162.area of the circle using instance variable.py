#pr no:162
#03/07/2020
#area of the circle using instance argument
class area_of_the_circle():
    __r=None
    __area=None
    def __init__(self,x=10):
        self.__r=x
    def setr(self,r):
        self.__r=r
    def reset(self):
        self.__init__()
    def findarea(self):
        self.__area=3.14*self.__r**2
    def printarea(self):
        print(self.__area)
a=area_of_the_circle()
a.findarea()
a.printarea()
a.setr(20)
a.findarea()
a.printarea()
a.reset()
a.findarea()
a.printarea()
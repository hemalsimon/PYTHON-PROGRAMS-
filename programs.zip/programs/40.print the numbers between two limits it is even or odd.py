#pr no 40
#01/06/2020
#print the between two limits using while loop to check the even or odd
a=int(input("value of a"))
b=int(input("value of b"))
while(a<=b):
    if(a%2==0):
        print("even")
    else:
        print("odd")
    a+=1
    print(a)
#pr no 194
#20/07/2020
#print the ascii value of the given character
a=input("value of a ")
print(ord(a))
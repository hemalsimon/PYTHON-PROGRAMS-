#pr no 62
#05/06/2020
#biggest of 10 numbers using while loop
i=1
b=int(input("enter the another no"))

while i<=10:
    a = int(input("enter the first no"))
    if a>b:
        b=a
    i+=1
print (b)
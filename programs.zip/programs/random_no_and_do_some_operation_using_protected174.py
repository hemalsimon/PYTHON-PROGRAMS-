#pr no 174
#08/07/2020
#random no and do some operation using protected
import random
class mathprogram():
    def __init__(self,a=-100,b=100,c=10):
        self._a=[]
        for i in range(c):
            n=random.randint(a,b)
            self._a.append(n)
    def printrandom(self):
        b=1
        for i in self._a:
            print(b,"random no=",i)
            b+=1
    def poscount(self):
        poscount=0
        for i in self._a:
            if i >0:
                poscount+=1
        return poscount
    def negcount(self):
        negcount=0
        for i in self._a:
            if i <0:
                negcount+=1
        return negcount
    def zerocount(self):
        zerocount=0
        for i in self._a:
            if i ==0:
                zerocount+=1
        return zerocount
    def possum(self):
        possum=0
        for i in self._a:
            if i>0:
                possum=possum+i
        return possum
    def negsum(self):
        negsum=0
        for i in self._a:
            if i<0:
                negsum=negsum+i
        return negsum
    def biggest(self):
        big=self._a[0]
        for i in self._a:
            big=i if i>big else big
        return big
    def smallest(self):
        small=self._a[0]
        for i in self._a:
            small=i if i<small else small
        return small
    def noeven(self):
        noeven=0
        for i in self._a:
            n=i%2==0
            if(not n):
                noeven+=1
        return noeven
    def noodd(self):
        noodd=0
        for i in self._a:
            n=i%2==0
            if(n):
                noodd+=1
        return noodd
"""
c=mathprogram()
c.printrandom()
print("\n")
print("positive count ",c.poscount())
print("negative count ",c.negcount())
print("positive sum ",c.possum())
print("negative sum ",c.negsum())
print("biggest no ",c.biggest())
print("smallest no ",c.smallest())
print("no of even ",c.noeven())
print("no of odd ",c.noodd())
"""
#pr.no:99
#19/06/2020
#construct a tuples to find the mean of n numbers
b=[]
i=0
n=10
while i<n:
    x=int(input("x "))
    b.extend([x])
    i+=1
a=tuple(b)
sum=0
n=len(a)
i=0
while i<n:
    sum=sum+a[i]
    i+=1
mean=0
mean=sum/n
print(sum)
print(mean)
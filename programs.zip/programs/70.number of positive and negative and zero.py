#pr no:69
#07/06/2020
#construct a list of a element until 1000 sum of the elements using list
a=[]
x=int(input("value of x "))
while x!=1000:
    a.append(x)
    x=int(input("value of x"))
n=len(a)
i=0
pos=0
neg=0
zero=0
while i<n:
    if a[i]>0:
        pos+=1
    elif a[i]<0:
        neg+=1
    else:
        zero+=1

    i+=1
print("positive",pos)
print ("negative",neg)
print("zero",zero)
#pr no :183
#14/07/2020
#read and display the points using read method
class base_points():
    _x=None
    _y=None
    def __init__(self,x=1,y=2):
        self._x=x
        self._y=y
    def __del__(self):
        print("deleted")
    def __str__(self):
        return "({0},{1})".format(self._x,self._y)
    def read(self):
        self._x=int(input("value of x"))
        self._y=int(input("value of y"))
    def seta(self,a):
        self._x=a
    def setb(self,b):
        self._y=b
    def setab(self,a,b):
        self._x=a
        self._y=b
    def geta(self):
        return self._x
    def getb(self):
        return self._y
    def getab(self):
        return self._x,self._y
    def reset(self):
        self.__init__()
    def print(self):
        print("x",self._x,end="\t")
        print("y",self._y)
"""
c=base_points()
d=base_points(40,50)
c.print()
d.print()
c.read()
c.print()
d.read()
d.print()
c.seta(10)
c.print()
c.setb(20)
c.print()
c.setab(30,60)
c.print()
d.seta(70)
d.print()
d.setb(80)
d.print()
d.setab(90,100)
d.print()
print(c.geta())
print(c.getb())
print(c.getab())
print(d.geta())
print(d.getb())
print(d.getab())
c.reset()
c.print()
d.reset()
d.print()
print(c)
print(d)
"""
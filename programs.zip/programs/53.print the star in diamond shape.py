    #pr no 53
#02/06/2020
#print the star in diamond shape using while loop
a=1
n=5#this is for space

m=1#this is for star
while (a<=6):
    b = 1
    while b<=n:
        print(" ",end=' ')
        b+=1
    c=1
    while c<=m:
            print("*",end=' ')
            c+=1
    print()
    a+=1
    n-=1
    m+=2
d=1
q=1#this is for space
p=9#this is for star
while (d<=5):
    e=1
    while e<=q:
        print(" ",end=' ')
        e+=1
    f=1
    while f<=p:
        print("*",end=' ')
        f+=1
    print()
    d+=1
    q+=1
    p-=2


#pr no:78
#11/06/2020
# find out the 2nd biggest element in list using list
a=[]
x=int(input("value of x "))
while x!=1000:
    a.append(x)
    x=int(input("value of x "))
n=len(a)
i=0
big=a[0]
while i<n:
    if a[i]>big:
        big=a[i]
    i+=1
print("first big number",big)
i=0
secondbig=-a[0]
while i<n:
    if a[i]!=big:
        print("a",[i],"=",a[i],"\tbig=",big,"\tsecondbig=",secondbig)
        if a[i]>secondbig:
            secondbig=a[i]
    i+=1
print ("second big number",secondbig)
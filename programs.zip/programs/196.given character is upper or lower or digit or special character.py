#pr no 196
#20/07/2020
#given character is upper or lower or digit or special character
a=input("value of a")
if 'a'<=a<='z':
    print("lower case")
elif 'A'<=a<='Z':
    print("upper case")
elif '0'<=a<='9':
    print("digit")
else:
    print("special character")
#pr no 225
#29/07/2020
#count the word no of times occurences in para
txt="he is a boy. he have have three elder brother"
d={}
words=txt.split()
print(words)
uniqueword=set()
uniqueword.update(words)
print(uniqueword)
for i in uniqueword:
    c=words.count(i)
    d[i]=c
for j in d.keys():
    print(j,end='\t')
    print("\t",d[j])


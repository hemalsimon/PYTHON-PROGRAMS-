import re
s="Ram is the St.Joseph's college trichy is student, trichy -624709,age=22"
r=re.match(r"is{2}",s)
#print(r.group())
if(r):
    print("there is match")
else:
    print("not match")
print(r)


#pr no 160
#02/01/2020
#smallest of three no constructor using default argument
class smallest_of_three:
    __a=None
    __b=None
    __c=None
    __small=None
    def __init__(self,a=100,b=200,c=300):
        self.__a=a
        self.__b=b
        self.__c=c
    def findbig(self):
        d=self.__a if self.__a<self.__b else self.__b
        self.__small=d if d<self.__c else self.__c
    def printbig(self):
        print("the smallest no is",self.__small)
x=smallest_of_three()
x.findbig()
x.printbig()
y=smallest_of_three(1000)
y.findbig()
y.printbig()
z=smallest_of_three(1000,2000)
z.findbig()
z.printbig()
g=smallest_of_three(1000,2000,3000)
g.findbig()
g.printbig()
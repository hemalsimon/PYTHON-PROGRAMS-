#pr no 187
#16/07/2020
#relational operation
from parent_points_184 import base_points
class relational_operators(base_points):
    pass
    def findsquare(self,firstpoint,nextpoint):
        p=firstpoint._x**2+firstpoint._y**2
        q=nextpoint._x**2+nextpoint._y**2
        return p,q
    def __lt__(self,nextpoint):
        x=self.findsquare(self,nextpoint)
        return x[0] < x[1]
    def __gt__(self, nextpoint):
        x = self.findsquare(self, nextpoint)
        return x[0] > x[1]
    def __eq__(self, nextpoint):
        x = self.findsquare(self, nextpoint)
        return x[0] == x[1]
    def __le__(self, nextpoint):
        x = self.findsquare(self, nextpoint)
        return x[0] <= x[1]
    def __ge__(self, nextpoint):
        x = self.findsquare(self, nextpoint)
        return x[0] >= x[1]
    def __ne__(self, nextpoint):
        x = self.findsquare(self, nextpoint)
        return x[0] != x[1]
"""
#main
c=relational_operators()
d=relational_operators(3,4)
print("less than\t\t\t",c<d)
print("greater than\t\t",c>d)
print("equal\t\t\t\t",c==d)
print("less than or equal\t\t",c<=d)
print("greator than or equal\t",c>=d)
print("not equal\t\t\t\t",c!=d)
"""





#this is big and make the power every time
"""
#pr no 187
#16/07/2020
#relational operation
from parent_points_184 import base_points
class relational_operator(base_points):
    pass
    def __lt__(self, nextpoint):
        p=self._x**2+nextpoint._x**2
        q=self._y**2+nextpoint._y**2
        print("x ",p," y ",q)
        return p < q
    def __gt__(self, nextpoint):
        p = self._x**2 + nextpoint._x**2
        q = self._y**2 + nextpoint._y**2
        return p > q
    def __eq__(self, nextpoint):
        p = self._x**2 + nextpoint._x**2
        q = self._y**2 + nextpoint._y**2
        return p == q
    def __le__(self, nextpoint):
        p = self._x**2 + nextpoint._x**2
        q = self._y**2 + nextpoint._y**2
        return p <= q
    def __ge__(self, nextpoint):
        p = self._x**2 + nextpoint._x**2
        q = self._y**2 + nextpoint._y**2
        return p >= q
    def __ne__(self, nextpoint):
        p = self._x**2 + nextpoint._x**2
        q = self._y**2 + nextpoint._y**2
        return p != q
"""
"""
#main
c=relational_operator()
d=relational_operator(40,50)
print(c)
print(d)
print("less than\t=",c<d)
print("greater than\t=",c>d)
print("equal\t=",c==d)
print("less than or equal\t=",c<=d)
print("greater than or equal\t=",c>=d)
print("not equal\t=",c!=d)  """
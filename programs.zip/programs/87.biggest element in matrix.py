#pr no 86
#15/06/2020
#biggest element in matrix
b=[]
i=0
while i<3:
    a=[]
    j=0
    while j<3:
        x=int(input('value of x'))
        a.append(x)
        j+=1
    b.append(a)
    i+=1
i=0
big=0
while i<3:
    j=0
    while j<3:
      if b[i][j]>big:
         big=b[i][j]
      j+=1
    i+=1
print(big)
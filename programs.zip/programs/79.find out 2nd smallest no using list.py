#pr no:79
#11/06/2020
# find out the 2nd smallest element in list using list
a=[]
x=int(input("value of x"))
while x!=1000:
    a.append(x)
    x=int(input("value of x"))
n=len(a)
i=0
small=a[0]
while i<n:
    if a[i]<small:
        small=a[i]
    i+=1
print("first small",small)
i=0
secondsmall=a[0]
while i<n:
    if a[i]!=small:
        print("a", [i], "=", a[i], "\tbig=", small, "\tsecondbig=", secondsmall)
        if a[i]<secondsmall:
            secondsmall=a[i]
    i+=1
print ("second small",secondsmall)
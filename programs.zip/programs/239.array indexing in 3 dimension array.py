import numpy as np
data=[[[1,2,3],[7,8,9]],[[4,5,6],[10,11,12]]]
arr=np.array(data)
print(arr)
print(arr[1,1,1])
#pr no 126
#24/06/2020
#count the no of positive and negative and zero
def readlist():
    b=[]
    x=int(input("x "))
    while x!=1000:
        b.append(x)
        x=int(input("x "))
    return b
def printlist(a):
    for i in a:
        print(i)
def count(b):
    n=len(b)
    pos=0
    neg=0
    zero=0
    for i in range(n):
        if b[i]>0:
            pos+=1
        elif b[i]<0:
            neg+=1
        else :
            zero+=1
    return pos,neg,zero
y=readlist()
printlist(y)
z=count(y)
print (z)

#pr.no:124
#22/06/2020
#create a list in 1st function
# index of the biggest no
def readlist():
    b=[]
    x=int(input("x "))
    while x!=1000:
        b.append(x)
        x=int(input("x "))
    return b
def printlist(a):
    for i in a:
        print(i)
def biggest(b):
    big=b[0]
    index=0
    n=len(b)
    for i in range(n):
        if b[i]>big:
            big=b[i]
            index=i
    print("big",big)
    return index
z=readlist()
printlist(z)
y=biggest(z)
print("index",y)

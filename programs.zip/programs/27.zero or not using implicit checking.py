# pr.no:27
#30/05/2020
#given integer no is zero or not using implicit checking

a=int(input("value of a "))
if (a):
    print(" not zero ")
else:
    print(" zero ")

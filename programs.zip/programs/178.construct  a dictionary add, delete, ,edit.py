#pr no 178
#11/07/2020
#construct a dictionary add, delete, edit
class dictionary():
    def __init__(self):
        self._a={}
    def addcontact(self):
        self._c=[]
        name = input("name ")
        ph_no = int(input("ph no "))
        address = input("address ")
        nickname = input("nickname ")
        self._c.extend([name, ph_no, address, nickname])
        self._a[ph_no]=self._c
    def deletecontact(self):
        contact = int(input("\nwhich contact do you delete "))
        d=self._a.keys()
        print("\n",d)
        if contact in d:
           del self._a[contact]
    def editcontact(self):
        contact = int(input("which contact do you want to edit "))
        d = self._a.keys()
        if contact in d:
            print("0 for name\n1 for phno\n2 for address\n3 for nickname ")
            a = int(input("which one do you delete "))
            if a == 0:
                name = input("change the name ")
                self._a[contact][a] = name
            if a == 1:
                ph_no = int(input("change the phno "))
                self._a[contact][a] = ph_no
            if a == 2:
                address = input("change the address ")
                self._a[contact][a] = address
            if a == 3:
                nickname = input("change the nick name ")
                self._a[contact][a] = nickname
    def searchcontact(self):
        give=input("give the field ")
        d=self._a.keys()
        for i in d:
            if give in str(self._a[i]):
                c=self._a[i]
        return c
    def print(self):
        d=self._a.keys()
        for i in d:
            print(self._a[i])
c=dictionary()
print("DONE BY \n       J HEMAL SIMON")
print("\n1 add contact\n2 display contacts\n3 search contact\n4 edit contact\n5 delete contact\n6 exit")
j=int(input("\ngive the input "))
while j!=6:
    if j==1:
        c.addcontact()
    elif j==2:
        c.print()
    elif j==3:
        print(c.searchcontact())
    elif j==4:
        c.editcontact()
    elif j==5:
        c.deletecontact()
    print("\n1 add contact\n2 display contacts\n3 search contact\n4 edit contact\n5 for delete contact\n6 for exit")
    j = int(input("\ngive the input "))
'''elif give.isdigit():
'''
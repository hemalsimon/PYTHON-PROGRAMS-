# pr.no:08
#30/05/2020
#volume of the sphere

r=int(input("value of r "))
c=4/3*3.14*r*r*r
print(c)
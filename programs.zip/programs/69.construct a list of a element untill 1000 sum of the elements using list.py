#pr no:69
#07/06/2020
#construct a list of a element until 1000 sum of the elements using list
a=[]
x=int(input("value of x "))
while x!=1000:
    a.append(x)
    x=int(input("value of x"))
n=len(a)
i=0
b=0
while i<n:
    b=b+a[i]

    i+=1
print(b)
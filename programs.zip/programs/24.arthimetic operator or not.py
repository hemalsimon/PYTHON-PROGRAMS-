# pr.no:24
#30/05/2020
#given integer no is arthimetic operator or not

a=(input("value of a "))
if a=='+' or a=='-' or a=='*' or a=='%' or a=='/':
    print("arthimetic operator")
else:
    print("not a arthimetic operator")

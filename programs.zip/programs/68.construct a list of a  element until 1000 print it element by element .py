#pr no:65
#07/06/2020
#construct a list of a element until 1000 print it element by element
a=[]
x=int(input("value of x "))
while x!=1000:
    a.append(x)
    x=int(input("value of x"))
n=len(a)
i=0
while i<n:
    print(a[i])
    i+=1

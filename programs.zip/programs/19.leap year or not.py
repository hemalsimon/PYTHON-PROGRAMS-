# pr.no:19
#30/05/2020
#given year is leap year or not

a=int(input("value of a "))
if a%4==0:
    print("leap year")
else:
    print ("not a leap year")

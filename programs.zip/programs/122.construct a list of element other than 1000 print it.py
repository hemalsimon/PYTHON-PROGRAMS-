#pr.no:122
#22/06/2020
#construct a list of element other than 1000 print it
def readlist():
    b=[]
    x=int(input("x "))
    while x!=1000:
        b.append(x)
        x=int(input("x "))
    return b
def printlist(a):
    n=len(a)
    for i in range(n):
        print(a[i])
    for i in a:
        print(i)
y=readlist()
printlist(y)

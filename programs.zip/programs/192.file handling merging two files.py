#pr no 191
#20/07/2020
#file handling copy from source file and paste from destination file
source1=input("source file1 ")
f1=open(source1,"r")
r1=f1.read()
source2=input("source file2 ")
f2=open(source2,"r")
r2=f2.read()
destination=input("destination ")
d=open(destination,"w")
w=d.write(r1)
w1=d.write(r2)
print(w)
print(w1)
"""
this print(w) is the how many character in the file including the spaces
"""
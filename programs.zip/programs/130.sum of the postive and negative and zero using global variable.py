#pr no 130
#26/06/2020
#sum of the positive and negative and zero using global variable
sumpos=0
sumneg=0
def readlist():
    b=[]
    x=int(input("x "))
    while x!=1000:
        b.append(x)
        x=int(input("x "))
    return b
def printlist(a):
    for i in a:
        print(i)
def count(b):
    n=len(b)
    global sumpos,sumneg
    for i in range(n):
        if b[i]>0:
            sumpos=sumpos+b[i]
        elif b[i]<0:
            sumneg=sumneg+b[i]
y=readlist()
printlist(y)
count(y)
print ("sumpos",sumpos)
print("sumneg",sumneg)


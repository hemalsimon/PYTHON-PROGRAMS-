#pr no 153
#01/07/2020
#biggest of three no using object oriented programming
class biggest_of_three_no:
    __a=None
    __b=None
    __c=None
    __d=None
    __e=None
    def set(self):
        self.__a=10
        self.__b=30
        self.__c=20
    def findbig(self):
        self.__d=self.__a if self.__a>self.__b else self.__b
        self.__e=self.__d if self.__d>self.__c else self.__c
    def printbig(self):
        print(self.__e)
f=biggest_of_three_no()
f.set()
f.findbig()
f.printbig()
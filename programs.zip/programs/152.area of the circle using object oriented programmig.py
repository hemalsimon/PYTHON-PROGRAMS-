#pr no 152
#01/07/2020
#area of the circle using object oriented programming
class area_of_the_circle:
    __r=None
    __area=None
    def set(self):
        self.__r=int(input("x "))
    def findarea(self):
        self.__area=3.14*self.__r**2
    def printarea(self):
        print(self.__area)
a=area_of_the_circle()
a.set()
a.findarea()
a.printarea()
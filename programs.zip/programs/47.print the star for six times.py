#pr no 47
#02/06/2020
# print the star for six times using while loop
a=1
while (a<=6):
    print("*",end='')
    a+=1
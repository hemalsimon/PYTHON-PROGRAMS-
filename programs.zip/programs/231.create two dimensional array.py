#pr no :231
#13/01/2020
#create two dimensional array
import numpy as np
a=np.array([[1.5,2.5,3.5],[4.5,5.5,6.5]],dtype=complex)
print(a)


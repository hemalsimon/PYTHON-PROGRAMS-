# pr.no:10
#30/05/2020
#given integer no is positive or not

a=int(input("value of a"))
if a>=0 :
    print ("positive")
else :
    print ("not positive")
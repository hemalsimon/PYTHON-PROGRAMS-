#pr no 159
#02/01/2020
#biggest of three no constructor using default argument
class biggest_of_three:
    __a=None
    __b=None
    __c=None
    def __init__(self,a=100,b=200,c=300):
        self.__a=a
        self.__b=b
        self.__c=c
    def findbig(self):
        d=self.__a if self.__a>self.__b else self.__b
        self.__e=d if d>self.__c else self.__c
    def printbig(self):
        print("the biggest no is",self.__e)
x=biggest_of_three()
x.findbig()
x.printbig()
y=biggest_of_three(1000)
y.findbig()
y.printbig()
z=biggest_of_three(1000,2000)
z.findbig()
z.printbig()
g=biggest_of_three(1000,2000,3000)
g.findbig()
g.printbig()
#pr no 219
#25/07/2020
#segregate the department by using their d-no's
import re
f=open("department.py","r")
f1=open("physics","w")
f2=open("information_technology","w")
f3=open("chemistry","w")
while r:=f.readline():
    line=re.search(r'\d{2}\w{3}\d{3}',r)
    start=line.start()
    end=line.end()
    x=r[start:end]
    if x[3]==('p'or'P'):
        f1.write(r)
    elif x[3]==('b'or'B'):
        f2.write(r)
    elif x[3]==('c'or'C'):
        f3.write(r)



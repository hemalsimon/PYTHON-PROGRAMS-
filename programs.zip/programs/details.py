sandy   22      trichy      658942735
ranjith 23      duraiyor    959647213
kishore 22      madurai     085423055
simon   23      dindigul    856245212
sandy   22      trichy      658942735
ranjith 23      duraiyor    959647213
kishore 22      madurai     085423055
simon   23      dindigul    856245212
hemal   21      combai
#pr.no:116
#22/06/2020
#area of the circle using default argument function
#pr.no:111
#22/06/2020
#area of the circle using function
def area(r=10):
    c=3.14*r**2
    return c
x=int(input("x "))
z=area(x)
print(z)
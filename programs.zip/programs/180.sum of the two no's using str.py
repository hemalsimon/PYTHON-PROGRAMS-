#pr no 154
#01/07/2020
#sum of the two interger no using constructor in object oriented programming
class sum_of_the_two_no:
    _x=None
    _y=None
    __sum=None
    def __init__(self):
        self.__x=10
        self.__y=20
    def __del__(self):
        print("deleted")
    def __str__(self):
        return "({0},{1},{2})".format(self.__x,self.__y,self.__sum)
    def findsum(self):
        self.__sum=self.__x+self.__y
    def printsum(self):
        print(self.__sum)
a=sum_of_the_two_no()
print(a)
a.findsum()
a.printsum()
print(a)



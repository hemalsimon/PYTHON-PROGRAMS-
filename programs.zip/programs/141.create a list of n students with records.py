#pr no :142
#29/06/2020
#create a list of n students with records
def records(n):
    b=[]
    for i in range (n):
        a=[]
        rollno=int(input("rollno "))
        name=(input("name "))
        age=int(input("age "))
        address=(input("address "))
        a.extend([rollno,name,age,address])
        b.append(a)
    return b
def printrecords(y,n):
    for i in range(n):
        print(y[i])
n=int(input("give the range "))
y=records(n)
printrecords(y,n)
#pr.no:111
#22/06/2020
#volume of the sphere using function
def sphere(r):
    c = 4/3*3.14 * r ** 2
    return c
x = int(input("x "))
z = sphere(x)
print(z)
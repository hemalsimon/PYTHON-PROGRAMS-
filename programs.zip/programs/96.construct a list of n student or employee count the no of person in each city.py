#pr no 96
#18/06/2020
#construct a list of n student employee count the no of person in each city
b=[]
i=0
while i<5:
    a=[]
    rollno=int(input("rollno "))
    name=(input("name "))
    age=int(input("age "))
    address=input("address")
    a.extend([rollno,name,age,address])
    b.append(a)
    i+=1
i=0
print("")
n=len(b)
dindigul=0
trichy=0
madurai=0
while i<n:
    if "dindigul" in b[i]:
        dindigul+=1
    elif "trichy" in b[i]:
        trichy+=1
    elif "madurai" in b[i]:
        madurai+=1
    i+=1
print("dindigul",dindigul)
print("trichy",trichy)
print("madurai",madurai)
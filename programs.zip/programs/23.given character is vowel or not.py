# pr.no:23
#30/05/2020
#given integer no is vowel or not

a=(input("value of a "))
if a=='a' or a=='e' or a=='i' or a=='o' or a=='u':
    print("vowel")
else:
    print("not vowel")

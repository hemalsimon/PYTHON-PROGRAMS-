#pr no 86
#15/06/2020
#row sum in matrix
b=[]
i=0
while i<3:
    a=[]
    j=0
    while j<3:
        x=int(input("value of x"))
        a.append(x)
        j+=1
    b.append(a)
    i+=1
i=0
j=int(input("select the row "))
sum=0
while i<3:
    sum=sum+b[j][i]
    i+=1
print (sum)

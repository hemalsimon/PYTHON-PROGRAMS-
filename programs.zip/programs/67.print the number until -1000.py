#pr no:65
#07/06/2020
#print the number untill 1000 using list
a=[]
x=int(input("value of x "))
while x!=1000:
    a.append(x)
    x=int(input("value of x "))
print(a)
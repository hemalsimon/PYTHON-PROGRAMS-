#pr no 43
#01/06/2020
# positive negative zero read and display until -1000
a=int(input("value of a"))
while(a!=-1000):
    if(a>0):
        print("positive")
    elif(a<0):
        print("negative")
    else:
        print("zero")
    print(a)
    a = int(input("value of a"))

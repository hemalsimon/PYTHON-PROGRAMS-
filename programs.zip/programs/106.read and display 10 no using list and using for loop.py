#pr no 106
#20/06/2020
#read and display 10 no using for loop
b=[]
for i in range(5):
    a=[]
    x=int(input("x "))
    a.extend([x])
    b.append(a)
print (b)
#pr no 39
#01/06/2020
#print the between two limits using while loop
a=int(input("value of a"))
b=int(input("value of b"))
while(a<=b):
    print(a)
    a+=1
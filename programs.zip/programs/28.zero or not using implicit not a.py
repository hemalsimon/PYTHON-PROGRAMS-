# pr.no:28
#01/06/2020
#given integer no is zero or not using implicit checking not

a=int(input("value of a "))
if ( not a):
    print(" zero ")
else:
   print(" not zero ")

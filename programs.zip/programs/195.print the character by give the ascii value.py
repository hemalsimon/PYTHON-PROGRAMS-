#pr no 195
#20/07/2020
#print the character by give the ascii value
a=int(input("value of a "))
print(chr(a))
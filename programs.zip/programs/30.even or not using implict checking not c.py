# pr.no:31
#01/06/2020
#given integer no is even or odd using implicit checking not c

a=int(input("value of a "))
c=a%2
if (not c):
    print("even")
else:
    print("odd")

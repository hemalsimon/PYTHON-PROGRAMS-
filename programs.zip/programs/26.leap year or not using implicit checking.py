# pr.no:26
#30/05/2020
#given integer no is leap year or not using implicit checking

a=int(input("value of a "))
c=a%4
if (c):
    print("not leap year ")
else:
    print ("leap year")

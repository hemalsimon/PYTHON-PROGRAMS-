#pr no 191
#20/07/2020
#file handling copy from source file and paste from destination file
source=input("source file ")
f=open(source,"r")
r=f.read()
destination=input("destination ")
d=open(destination,"w")
w=d.write(r)
print(w)
"""
this print(w) is the how many character in the file including the spaces
"""
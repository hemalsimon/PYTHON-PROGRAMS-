#pr no 158
#02/07/2020
#sum of the two no in constructor using default argument
class sum_of_the_two_no():
    __a=None
    __b=None
    __sum=None
    def __init__(self,x=10,y=20):
        self.__a=x
        self.__b=y
    def findsum(self):
        self.__sum=self.__a+self.__b
    def printsum(self):
        print(self.__sum)
c=sum_of_the_two_no()
c.findsum()
c.printsum()
d=sum_of_the_two_no(100)
d.findsum()
d.printsum()
e=sum_of_the_two_no(100,200)
e.findsum()
e.printsum()
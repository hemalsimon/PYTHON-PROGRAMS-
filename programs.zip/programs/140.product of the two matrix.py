#pr no 140
#27/06/2020
#find the product of the two matrix
def readmatrix(n):
    b=[]
    for i in range(n):
        a=[]
        for j in range(n):
            x=int(input("x "))
            a.append(x)
        b.append(a)
    return b
def printmatirxforx(x,n):
    print("matrix of x")
    for i in range(n):
        for j in range(n):
            print(x[i][j],end=' ')
        print(" ")

def printmatirxfory(y, n):
        print("matrix of y")
        for i in range(n):
            for j in range(n):
                print(y[i][j], end=' ')
            print(" ")
def productofthetwomatrix(x,y,n):
    b = []
    for k in range(n):
        a = []
        for i in range(n):
            sum = 0
            for j in range(n):
                product=x[k][j]*y[j][i]
                sum=sum+product
            a.append(sum)
        b.append(a)
    return b
def printmatirx(z,n):
    print("product of the two matrix")
    for i in range(n):
        for j in range(n):
            print(z[i][j],end=' ')
        print(" ")
n=int(input("size of matrix "))
x=readmatrix(n)
y=readmatrix(n)
printmatirxforx(x,n)
printmatirxfory(y,n)
z=productofthetwomatrix(x,y,n)
printmatirx(z,n)
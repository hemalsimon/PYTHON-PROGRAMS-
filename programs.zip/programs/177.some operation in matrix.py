#pr no 177
#11/07/2020
#some operation in matrix
from matrix1_176 import matrix
class some_operation(matrix):
    pass
    def sum_of_the_matrix(self):
        sum=0
        row = len(self._b)
        column = len(self._b[0])
        print("row",row)
        print("column",column)
        for i in range(row):
            for j in range(column):
                sum=sum+self._b[i][j]
        return sum
    def biggest_of_element(self):
        row = len(self._b)
        column = len(self._b[0])
        big=self._b[0][0]
        for i in range(row):
            for j in range(column):
                if self._b[i][j]>big:
                    big=self._b[i][j]
        return big
    def smallest_of_element(self):
        small=self._b[0][0]
        row = len(self._b)
        column = len(self._b[0])
        for i in range(row):
            for j in range(column):
                if self._b[i][j]<small:
                    small=self._b[i][j]
        return small
    def biggest_element_in_column(self,a):
        big=self._b[0][a]
        row = len(self._b)
        column = len(self._b[0])
        for i in range(row):
            if self._b[i][a]>big:
                big=self._b[i][a]
        return big
    def smallest_element_in_row(self,b):
        small=self._b[b][0]
        row = len(self._b)
        column = len(self._b[0])
        for i in range(column):
            if self._b[b][i]<small:
                small=self._b[b][i]
        return small
c=some_operation()
c.print()
print("\n")
print("sum",c.sum_of_the_matrix())
print("biggest element in matrix",c.biggest_of_element())
print("smallest element in matrix",c.smallest_of_element())
print("\n")
a=int(input("give the column"))
print("biggest element in ",a,"column",c.biggest_element_in_column(a))
print("\n")
b=int(input("give the row"))
print("smalest element in ",b,"row",c.smallest_element_in_row(b))
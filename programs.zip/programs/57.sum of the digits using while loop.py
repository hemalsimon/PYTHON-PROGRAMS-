#pr no 57
#04/06/2020
#sum of the digits using while loop
q=int(input("value ofq"))
r=1
s=0
while q!=0:
    r=q%10
    q=int(q/10)
    s=s+r
print(s)

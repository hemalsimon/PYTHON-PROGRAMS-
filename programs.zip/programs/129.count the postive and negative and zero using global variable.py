#pr no 129
#26/06/2020
#count the no of positive and negative and zero using global variable
pos=0
neg=0
zero=0
def readlist():
    b=[]
    x=int(input("x "))
    while x!=1000:
        b.append(x)
        x=int(input("x "))
    return b
def printlist(a):
    for i in a:
        print(i)
def count(b):
    n=len(b)
    global pos,neg,zero
    for i in range(n):
        if b[i]>0:
            pos+=1
        elif b[i]<0:
            neg+=1
        else :
            zero+=1
y=readlist()
printlist(y)
count(y)
print ("pos",pos)
print("neg",neg)
print("zero",zero)

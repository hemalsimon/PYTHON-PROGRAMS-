#pr no 202
#20/07/2020
#split the words and sentences and statements and lines
text="""
hi.
hello;
how.
"""
print(text)
s=text.split()
print(s)
print("no of text",len(s))
t=text.split('.')
print("split words",t)
print("no of words",len(t))
l=text.splitlines()
print("split lines",l)
print("no of lines",len(l))
m=text.split(';')
print("split statements",m)
print("no of statements",len(m))
print("no of character",len(text))
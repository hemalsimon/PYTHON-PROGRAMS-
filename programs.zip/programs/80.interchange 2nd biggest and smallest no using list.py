#pr no:90
#11/06/2020
# interchange the 2nd biggest and 2nd smallest  using list
a=[]
x=int(input("value of x"))
while x!=1000:
    a.append(x)
    x=int(input("value of x"))
n=len(a)
i=0
big=small=a[0]
while i<n:
    if a[i]>big:
        big=a[i]
    elif a[i]<small:
        small=a[i]
    i+=1
print(a)
print(big,"big")
print(small,"small")
i=0
secondbig=secondsmall=a[0]
secondbigindex=secondsmallindex=0
while i<n:
    if a[i]!=big:
        if a[i]>secondbig:
            secondbig=a[i]
            secondbigindex=i
    elif a[i]!=small:
        if a[i]<secondsmall:
            secondsmall=a[i]
            secondsmallindex=i
    i+=1
print ("secondbig",secondbig)
print("secondsmall",secondsmall)
print("secondbigindex",secondbigindex)
print("secondsmallindex",secondsmallindex)
a[secondbigindex]=small
a[secondsmallindex]=big
print(a)
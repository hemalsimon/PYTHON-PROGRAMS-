#pr no 168
#06/07/2020
#accessing the last program from this program

from accessing_two_values166 import accessing_two_no
'''
syntax for above line
from file name import class name
'''
class child(accessing_two_no):
    '''
    syntax for above line
    class son(dad)
    '''
    pass
    def sum(self):
        c=self.geta()+self.getb()
        return c
    def diff(self):
        c=self.geta()-self.getb()
        return c
    def prod(self):
        c=self.geta()*self.getb()
        return c
    def quotion(self):
        c=self.geta()/self.getb()
        return c
    def big(self):
        c=self.geta() if self.geta()>self.getb() else self.getb()
        return c
    def small(self):
        c=self.geta() if self.geta()<self.getb() else self.getb()
        return c
d=child()
d.seta(1000)
print("after set a value")
d.printvalues()
d.setb(2000)
print("after set b value")
d.printvalues()
d.setab(400,500)
print("after set a,b value")
d.printvalues()
print("get a value\t ",d.geta())
print("get b value\t ",d.getb())
print("get a,b value\t",d.getab())
d.reset()
print("\nafter reset")
d.printvalues()
print("sum",d.sum())
print("difference",d.diff())
print("product",d.prod())
print("quotion",d.quotion())
print("big",d.big())
print("small",d.small())
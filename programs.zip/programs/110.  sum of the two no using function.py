#pr no 110
#22/06/2020
#sum of the two integer no using function
def sum(a,b):
    c=a+b
    return c
x=int(input("x "))
y=int(input("y "))
z=sum(x,y)
print("sum=",z)
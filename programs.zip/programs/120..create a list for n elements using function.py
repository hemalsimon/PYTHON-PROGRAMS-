#pr.no:119
#22/06/2020
#create a list for n elements using function
def list():
    b=[]
    for i in range(10):
        x=int(input("x "))
        b.append(x)
    return b
z=list()
print(z)
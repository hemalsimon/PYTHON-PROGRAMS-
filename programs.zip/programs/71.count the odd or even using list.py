#pr no:69
#07/06/2020
#count the no of odd and even using list
a=[]
x=int(input("value of x "))
while x!=1000:
    a.append(x)
    x=int(input("value of x "))
n=len(a)
even=0
odd=0
i=0
while i<n:
    if a[i]%2==0:
        even+=1
    else:
        odd+=1
    i+=1
print("even",even)
print("odd",odd)
#pr no 205
#21/07/2020
#read line by line and give the line no
source=input("source ")
f=open(source,"r")
r=f.readline()
line=0
while len(r):
    line=line+1
    print(line,end='\t')
    print(r,end='')
    r=f.readline()
# pr.no:04
#30/05/2020
#area of the triangle

b=10
h=20
c=1/2*b*h
print(c)
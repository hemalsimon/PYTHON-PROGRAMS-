#pr no 168
#06/07/2020
#accessing the last program from this program

from accessing_two_values166 import accessing_two_no
'''
syntax for above line
from file name import class name
'''
class child(accessing_two_no):
    '''
    syntax for above line
    class 
    '''
    pass
d=child()
d.seta(1000)
print("after set a value")
d.printvalues()
d.setb(2000)
print("after set b value")
d.printvalues()
d.setab(400,500)
print("after set a,b value")
d.printvalues()
print("get a value\t ",d.geta())
print("get b value\t ",d.getb())
print("get a,b value\t",d.getab())
d.reset()
print("\nafter reset")
d.printvalues()

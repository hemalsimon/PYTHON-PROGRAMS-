#pr no 167
#06/07/2020
#accessing two values
class accessing_two_no():
    __a=None
    __b=None
    def __init__(self,a=100,b=300):
        print("\nbeginning stage set a and b  the given values is")
        self.__a=a
        self.__b=b
        print("value of a",self.__a,"\nvalue of b",self.__b,"\n")
    def seta(self,a):
        self.__a=a
    def setb(self,b):
        self.__b=b
    def setab(self,a,b):
        self.__a=a
        self.__b=b
    def geta(self):
        return self.__a
    def getb(self):
        return self.__b
    def getab(self):
        return self.__a,self.__b
    def reset(self):
        self.__init__()
    def printvalues(self):
        print("value of a",self.__a)
        print("value of b",self.__b)
        print("\n")
'''
c=accessing_two_no()
c.seta(1000)
print("after set a value")
c.printvalues()
c.setb(2000)
print("after set b value")
c.printvalues()
c.setab(400,500)
print("after set a,b value")
c.printvalues()
print("get a value\t ",c.geta())
print("get b value\t ",c.getb())
print("get a,b value\t",c.getab())
c.reset()
print("\nafter reset")
c.printvalues()
'''
#pr no 134
#26/06/2020
#construct a 3x3 matrix in 1st function and transpores in 2nd functions and print it in 3rd function
def matrix(n):
    b=[]
    for i in range(n):
        a=[]
        for j in range(n):
            x=int(input("x "))
            a.extend([x])
        b.append(a)
    return b
def beftranspors(a,n):
    print("befor transpores")
    for i in range(n):
        for j in range(n):
           print(a[i][j],end=' ')
        print(" ")
def transpors(a,n):
    c=[]
    for i in range(n):
        d=[]
        for j in range(n):
           d.append(a[j][i])
        c.append(d)
    return c
def printtranspores(a,n):
    print("after transpores")
    for i in range(n):
        for j in range(n):
            print(a[i][j],end=' ')
        print("")
n=int(input("size of matrix"))
y=matrix(n)
beftranspors(y,n)
z=transpors(y,n)
printtranspores(z,n)

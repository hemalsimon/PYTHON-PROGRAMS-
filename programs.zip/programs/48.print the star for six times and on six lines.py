#pr no 48
#02/06/2020
# print the star for six times and on six lines using while loop
a=1
while (a<=6):
    b = 1
    while b<=6:
        print("*",end='')
        b+=1
    a+=1
    print("")
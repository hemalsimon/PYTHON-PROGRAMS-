#pr no 51
#02/06/2020
# print the star in six lines but refelect it in opposite side
a=1
n=5
m=1
while (a<=6):
    b = 1
    while b<=n:
        print(" ",end=' ')
        b+=1
    c=1
    while c<=m:
            print("*",end=' ')
            c+=1
    print()
    a+=1
    n-=1
    m+=1

#pr no 188
#17/07/2020
#points arthimetic, points relation
"""multi level inheritance"""
from point_arthimetic_operation186 import arthimetic_operators
from point_relational_operation187 import relational_operators
class points(arthimetic_operators,relational_operators):
    pass
#main
c=points()
d=points(50,100)
c.print()
d.print()
c.seta(10)
c.print()
c.setb(20)
c.print()
c.setab(30,60)
c.print()
d.seta(70)
d.print()
d.setb(80)
d.print()
d.setab(90,100)
d.print()
print(c.geta())
print(c.getb())
print(c.getab())
print(d.geta())
print(d.getb())
print(d.getab())
c.reset()
c.print()
d.reset()
d.print()
print(c)
print(d)
print("addition",c+d)
print("subraction",c-d)
print("multiplication",c*d)
print("less than\t\t\t",c<d)
print("greater than\t\t",c>d)
print("equal\t\t\t\t",c==d)
print("less than or equal\t\t",c<=d)
print("greator than or equal\t",c>=d)
print("not equal\t\t\t\t",c!=d)
#pr no 169
#06/07/2020
#accessing the last program from this program

from accessing_two_values166 import accessing_two_no
class child_accessing_three_no(accessing_two_no):
    pass
    __c=None
    def __init__(self,a=1001,b=2002,c=3003):
        accessing_two_no.__init__(self,a,b)
        self.__c=c
    def setc(self,c):
        self.__c=c
    def setabc(self,a,b,c):
        accessing_two_no.setab(self,a,b)
        self.__c=c
    def getc(self):
        return self.__c
    def getabc(self):
        return self.geta(),self.getb(),self.__c
    def reset(self):
        self.__init__()
    def print(self):
        print(self.__c)
"""
d=child_accessing_three_no()
print("after set a")
d.seta(1000)
d.printvalues()
print("after set b")
d.setb(2000)
d.printvalues()
print("after set c")
d.setc(3000)
d.print()
print("")
print("after set a,b")
d.setab(101,202)
d.printvalues()
print("set a,b,c")
d.setabc(1002,2003,3004)
d.printvalues()
print("value of c",end=' ')
d.print()
d.reset()
print("value of c",end=' ')
d.print()
print("\nget a\t",d.geta())
print("get b\t",d.getb())
print("get c\t",d.getc())
print("get a,b\t",d.getab())
print("get a,b,c\t",d.getabc())
"""
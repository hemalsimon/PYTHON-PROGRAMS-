#pr no 104
#19/06/2020
#create a dictionary for n no of  student
b=[]
a={}
n=2
i=0
while i<n:
    rollno=int(input("rollno "))
    name=(input("name "))
    age=int(input("age"))
    address=(input("address"))
    b.extend([rollno,name,age,address])
    a[rollno]=b
    i+=1
print (a)
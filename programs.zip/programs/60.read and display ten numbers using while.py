#pr no 61
#05/06/2020
#print and display 10 numbers using while
i=1
while(i<=10):
    a=int(input("enter number"))
    print(a)
    i+=1
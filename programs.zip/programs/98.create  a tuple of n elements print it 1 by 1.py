#pr.no 94
#19/06/2020
#create a tuple of n elements print in 1 by 1
b=[]
i=0
n=10
while i<n:
    x=int(input("x "))
    b.extend([x])
    i+=1
a=tuple(b)
n=len(a)
i=0
while i<n:
    print(a[i])
    i+=1
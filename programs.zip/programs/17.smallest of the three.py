# pr.no:17
#30/05/2020
#given integer no is smallest of three

a=int(input("value of a "))
b=int(input("value of b "))
c=int(input("value of c "))           
if a<b:
    if a<c :
        print("a is small")
    else:
        print ("c is small")
elif b<c:
    print(" b is small")
else:
    print("c is small")
#pr no 58
#04/06/2020
#add birth year and give the zodiac
q=int(input("value ofq"))
r=1
s=0
x=0
while q!=0:
    r=q%10
    q=int(q/10)
    s=s+r
while s!=0:
    i=s%10
    s=int(s/10)
    x=x+i
print(x)
if x==1:
    print("aries")
elif x==2:
    print("taurus")
elif x==3:
    print("gemini")
elif x==4:
    print("cancer")
elif x==5:
    print("leo")
elif x==6:
    print("virgo")
elif x==7:
    print("libra")
elif x==8:
    print("scorpio")
else:
    print("pisces")

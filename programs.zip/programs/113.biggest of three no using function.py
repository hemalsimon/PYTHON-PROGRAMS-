#pr.no:113
#22/06/2020
#biggest of three no using function
def biggest(a,b,c):
    d=a if a>b else b
    e=d if d>c else c
    return e
x=int(input("x "))
y=int(input("y "))
z=int(input("z "))
o=biggest(x,y,z)
print(o)
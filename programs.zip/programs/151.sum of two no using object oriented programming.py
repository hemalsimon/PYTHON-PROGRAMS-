#pr no :151
#01/07/2020
#sum of the two no using object oriented programming
class sum_of_two_no:
    __x=None
    __y=None
    __sum=None
    def set(self):
        self.__x=10
        self.__y=20
    def findsum(self):
        self.__sum=self.__x+self.__y
    def printsum(self):
        print(self.__sum)
a=sum_of_two_no()
a.set()
a.findsum()
a.printsum()
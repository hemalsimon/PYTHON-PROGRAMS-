#pr no 50
#02/06/2020
# print the star in six lines under ascending order using while loop
a=1
n=1
while (a<=6):
    b = 1
    while b<=n:
        print("*",end='')
        b+=1
    a+=1
    n+=2
    print("")
#pr no 46
#02/06/2020
# average of positive negative zero read and display until -1000
a=int(input("value of a"))
b=0; c=0; d=0; e=0; f=0; g=0; h=0; i=0; j=0
while a!=-1000:
    if a>0:
        b=b+a
        e+=1
    elif a<0:
        c=c+a
        f+=1
    else :
        d=d+a
        g+=1
    print("sum of positive no : ",b)
    print("sum of negative no : ",c)
    print("sum of zeros no : ",d)
    print("")
    print("no of postive no : ",e)
    print("no of negative no : ",f)
    print("no of zero no : ",g)
    h=b/e if e !=0 else 0
    i=c/f if f !=0 else 0
    j=d/g if g !=0 else 0
    print("")
    print("average of positive",h)
    print("average of negative",i)
    print("average of zeros",j)
    a=int(input("value of a"))
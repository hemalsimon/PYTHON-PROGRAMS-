#pr no 136
#27/06/2020
#read n matrix in first function and print it in second function and sum in third function
def readmatrix(n):
    b=[]
    for i in range(n):
        a=[]
        for j in range(n):
            x=int(input("x "))
            a.extend([x])
        b.append(a)
    return b
def printmatirx(y,n):
    for i in range(n):
        for j in range(n):
           print(y[i][j],end=' ')
        print(" ")
def summatrix(y,n,row):
    sum=0
    for j in range(n):
        sum=sum+y[row][j]
    return sum
n=int(input("size of matrix "))
y=readmatrix(n)
printmatirx(y,n)
row=(int(input("give the row ")))
print("sum of the row",summatrix(y,n,row))
number=[1,2,5,8,7,9,6,4,1,3,2,5,1,2,4,8,9,6,2,1,3,5,4,2,1]
frequency={}
uniqueno=set(number)
print(number)
print(uniqueno)
for i in uniqueno:
    c=number.count(i)
    frequency[i]=c
for j in frequency.keys():
    print(j,"=",frequency[j])
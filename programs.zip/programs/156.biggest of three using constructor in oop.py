#pr no:156
#01/07/2020
#biggest of three using constructor in oop
class biggest_of_three:
    _a=None
    _b=None
    _c=None
    _d=None
    _e=None
    def __init__(self):
        self._a=50
        self._b=30
        self._c=40
    def findbig(self):
        self._d=self._a if self._a>self._b else self._b
        self._e=self._d if self._d>self._c else self._c
    def printbig(self):
        print("the biggest no is",self._e)
x=biggest_of_three()
x.findbig()
x.printbig()
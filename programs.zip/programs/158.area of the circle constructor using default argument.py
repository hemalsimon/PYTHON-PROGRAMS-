#pr no:158
#02/07/2020
#area of the circle constructor using default argument
class area_of_the_circle():
    __r=None
    __area=None
    def __init__(self,x=10):
        self.__r=x
    def findarea(self):
        self.__area=3.14*self.__r**2
    def printarea(self):
        print(self.__area)
a=area_of_the_circle()
a.findarea()
a.printarea()
b=area_of_the_circle(20)
b.findarea()
b.printarea()

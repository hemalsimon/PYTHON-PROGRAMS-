#pr no 90
#15/06/2020
#add the students records in list
a=[]
rollno=int(input("roll no "))
name=(input("name "))
age=int(input("age"))
address=(input("address"))
a.extend([rollno,name,age,address])
print(a)
#pr no :185
#14/07/2020
#add the two points
from parent_points_184 import base_points
class points(base_points):
    def __add__(self, nextpoint):
        q=self._x+nextpoint._x
        r=self._y+nextpoint._y
        return q,r
c=points()
d=points(50,50)
print(c)
print(d)
p=c+d
print(p)
"""
dynamic polymorphism
"""
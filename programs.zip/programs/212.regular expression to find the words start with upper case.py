import re
s="Ram is student of St.Joseph's College"
x=re.findall('[A-Z][a-z]*',s)
print(x)
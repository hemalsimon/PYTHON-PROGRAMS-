# pr.no:15
#30/05/2020
#given integer no is smallest of two

a=int(input("value of a "))
b=int(input("value of b "))
if a<b:
    print("a is small")
else:
    print("b is small")
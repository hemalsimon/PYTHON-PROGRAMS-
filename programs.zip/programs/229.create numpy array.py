#pr no :229
#13/01/2020
#create numpy array
import numpy as np
a=np.array()
print(a)

#pr no 150
#30/06/2020
#create a list from dictionary list of who are living in particular city
def constructdictionary(n):
    c={}
    for i in range(n):
        a=[]
        rollno=int(input("rollno="))
        name=input("name ")
        age=int(input("age "))
        address=input("address ")
        a.extend([rollno,name,age,address])
        c[rollno]=a
    return c
def who_are_living_in_particular_city(x,city):
    key=x.keys()
    b=[]
    print(key)
    for i  in key:
        if city in x[i]:
            b.append(x[i])
    return b
def printlist(y):
    n=len(y)
    for i in range(n):
        print(y[i])
n=int(input("give the range "))
x=constructdictionary(n)
city=input("give the city ")
y=who_are_living_in_particular_city(x,city)
printlist(y)
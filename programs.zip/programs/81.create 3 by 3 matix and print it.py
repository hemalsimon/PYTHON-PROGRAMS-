#pr no 81
#12/06/2020
#3 x 3 matrix
b=[]
i=0
while i<3:
    a = []
    j = 0
    while j<3:
        x=int(input("value of x"))
        a.append(x)
        j+=1
    i += 1
    print(a)
    a.clear()
    b.append(a)
print (b)


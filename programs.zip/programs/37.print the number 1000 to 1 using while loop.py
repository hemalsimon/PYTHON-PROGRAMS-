#pr no 37
#01/06/2020
#print the number 1000 to 1 using while loop

i=1000
while i>=1:
    print(i)
    i-=1
# pr.no:13
#30/05/2020
#given integer no is positive,negative,zero or not

a=int(input("value of a "))
if a>=0 :
    print ("positive")
elif a<=0 :
    print ("negative")
else :
    print ("zero")
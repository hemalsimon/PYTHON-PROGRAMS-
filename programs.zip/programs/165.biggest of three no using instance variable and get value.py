#pr no 165
#03/01/2020
#biggest of three no using instance variable and get value
class biggest_of_three:
    __a=None
    __b=None
    __c=None
    __big=None
    def __init__(self,a=100,b=200,c=300):
        self.__a=a
        self.__b=b
        self.__c=c
    def seta(self,a):
        self.__a=a
    def setb(self,b):
        self.__b=b
    def setc(self,c):
        self.__c=c
    def setabc(self,a,b,c):
        self.__a=a
        self.__b=b
        self.__c=c
    def reset(self):
        self.__init__()
    def geta(self):
        return self.__a
    def getb(self):
        return self.__b
    def getc(self):
        return self.__c
    def getabc(self):
        return self.__a,self.__b,self.__c
    def getbig(self):
        return self.__big
    def findbig(self):
        d=self.__a if self.__a>self.__b else self.__b
        self.__big=d if d>self.__c else self.__c
    def printbig(self):
        print("the biggest no is",self.__big)
x=biggest_of_three()
x.findbig()
x.printbig()
x.seta(1000)
x.findbig()
x.printbig()
x.setb(2000)
x.findbig()
x.printbig()
x.setc(3000)
x.findbig()
x.printbig()
x.setabc(400,500,600)
x.findbig()
x.printbig()
x.reset()
x.findbig()
x.printbig()
print("get a value\t",x.geta())
print("get b value\t",x.getb())
print("get c value\t",x.getc())
print("get a,b,c value\t",x.getabc())
print("get big value\t",x.getbig())
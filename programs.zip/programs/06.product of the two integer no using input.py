# pr.no:06
#30/05/2020
#product of two integer no

a=int(input("value of a "))
b=int(input("value of b "))
c=a*b
print(c)
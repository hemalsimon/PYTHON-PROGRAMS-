#pr no 134
#26/06/2020
#construct a 3x3 matrix in 1st function and transpores in 2nd functions and print it in 3rd function
def matrix():
    b=[]
    for i in range(3):
        a=[]
        for j in range(3):
            x=int(input("x "))
            a.extend([x])
        b.append(a)
    return b
def beftranspors(a):
    print("befor transpores")
    for i in range(3):
        for j in range(3):
           print(a[i][j],end=' ')
        print(" ")
def transpors(a):
    c=[]
    for i in range(3):
        d=[]
        for j in range(3):
           d.append(a[j][i])
        c.append(d)
    return c
def printtranspores(a):
    print("after transpores")
    for i in range(3):
        for j in range(3):
            print(a[i][j],end=' ')
        print("")
y=matrix()
beftranspors(y)
z=transpors(y)
printtranspores(z)

#pr no 109
#20/06/2020
#create a dictionary and print dindigul peoples only
b=[]
c={}
n=3
for i in range(n):
    a=[]
    rollno=int(input("rollno "))
    name=(input("name "))
    age=int(input("age"))
    address=(input("address"))
    gender=(input("gender"))
    a.extend([rollno,name,age,address,gender])
    c[rollno]=a
d=c.keys()
print (d)
for i in d:
    if c[i][3]=="dindigul":
        print(c[i])
print("\n")
for i in d:
    if c[i][4]=="male":
        print(c[i])
print("\n")
for i in d:
    if 'male' in c[i]:
        print(c[i])





#pr.no 94
#19/06/2020
#construct a tuple of n elements
b=[]
i=0
while i<10:
    x=int(input("value of x "))
    b.extend([x])
    i+=1
a=tuple(b)
print(a)
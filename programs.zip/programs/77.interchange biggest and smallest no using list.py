#pr.no:76
#11/06/2020
#index of the biggest and smallest no
a=[]
i=0
x=int(input("value of a"))
while x!=1000:
    a.append(x)
    x=int(input("value of x"))
n=len(a)
i=0
big=small=a[0]
bigindex=smallindex=0
while i<n:
    if a[i]>big:
        big=a[i]
        bigindex=i
    elif a[i]<small:
        small=a[i]
        smallindex=i
    i+=1
a[bigindex]=small
a[smallindex]=big
i=0
while i<n:
    print(a[i])
    i+=1

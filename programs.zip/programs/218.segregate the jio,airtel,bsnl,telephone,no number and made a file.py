#pr no 217
#23/07/2020
#segregate the jio,airtel,bsnl,telephone,no number and made a file
import re
f=open("details.py","r")
f1=open("jiouser","w")
f2=open("airteluser","w")
f3=open("bsnluser","w")
f4=open("telephoneno","w")
f5=open("nonumber","w")

while r:=f.readline():
    line=re.search(r'\d{9}',r)
    if (line):
        start=line.start()
        end=line.end()
        x=r[start:end]
        if x[0]=='6':
            f1.write(r)
        elif x[0]=='9':
            f2.write(r)
        elif x[0]=='8':
            f3.write(r)
        elif x[0]=='0':
            f4.write(r)
    else:
        f5.write(r)

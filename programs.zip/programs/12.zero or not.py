# pr.no:11
#30/05/2020
#given integer no is zero or not

a=int(input("value of a "))
if a==0 :
    print ("zero")
else :
    print ("not zero")
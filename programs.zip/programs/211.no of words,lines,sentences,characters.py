#pr no 211
#21/07/2020
#no of words,lines,sentences,characters
sourcefile=input("source file ")
f=open(sourcefile,"r")
words=0
count=0
sentences=0
characters=0
while len(r:=f.readline()):
    print(r,end='')
    words=len(r.split())+words
    count+=1
    sentences=len(r.split('.'))+sentences
    characters=characters+len(r)
print("\n\nno of words",words)
print("no of lines",count)
print("no of sentences",sentences)
print("no of characters",characters)
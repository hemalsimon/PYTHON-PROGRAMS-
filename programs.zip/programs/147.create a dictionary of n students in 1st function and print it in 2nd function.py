#pr no 146
#30/06/2020
#create a dictionary of n students in 1st function and print it in 2nd function
def constructdictionary(n):
    b=[]
    c={}
    for i in range(n):
        a=[]
        rollno=int(input("rollno="))
        name=input("name ")
        age=int(input("age "))
        address=input("address ")
        a.extend([rollno,name,age,address])
        c[rollno]=a
    return c
def printkeys(x):
    m=x.keys()
    print(m)
    for i in m:
        print(x[i])
n=int(input("give the range "))
x=constructdictionary(n)
printkeys(x)
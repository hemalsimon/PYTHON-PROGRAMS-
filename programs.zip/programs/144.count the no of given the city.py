#pr no :143
#29/06/2020
#count the no of given the city
def records(n):
    b=[]
    for i in range (n):
        a=[]
        rollno=int(input("rollno "))
        name=(input("name "))
        age=int(input("age "))
        address=(input("address "))
        a.extend([rollno,name,age,address])
        b.append(a)
    return b
def particularcity(n,y,city):
    countpeople=0
    for i in range(n):
        if city in y[i]:
           countpeople+=1
    return countpeople
n=int(input("give the range "))
y=records(n)
city=input("give the city")
print(particularcity(n,y,city))
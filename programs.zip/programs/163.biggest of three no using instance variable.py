#pr no 163
#03/01/2020
#biggest of three no using instance variable
class biggest_of_three:
    __a=None
    __b=None
    __c=None
    def __init__(self,a=100,b=200,c=300):
        self.__a=a
        self.__b=b
        self.__c=c
    def seta(self,a):
        self.__a=a
    def setb(self,b):
        self.__b=b
    def setc(self,c):
        self.__c=c
    def setabc(self,a,b,c):
        self.__a=a
        self.__b=b
        self.__c=c
    def reset(self):
        self.__init__()
    def findbig(self):
        d=self.__a if self.__a>self.__b else self.__b
        self.__e=d if d>self.__c else self.__c
    def printbig(self):
        print("the biggest no is",self.__e)
x=biggest_of_three()
x.findbig()
x.printbig()
x.seta(1000)
x.findbig()
x.printbig()
x.setb(2000)
x.findbig()
x.printbig()
x.setc(3000)
x.findbig()
x.printbig()
x.setabc(400,500,600)
x.findbig()
x.printbig()
x.reset()
x.findbig()
x.printbig()
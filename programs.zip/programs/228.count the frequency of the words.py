#pr no 226
#30/07/2020
#count the frequency of the words
import re
file=open("tamil bible.py","r")
file1=open("chapter analysis.py","w")
d={}
prep='1','2','3','4','5','6','7','8','its','and','9','10','11','12','to','let','his','were','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','at','a','that','from','there','is','you','it','he','you','your','also','they','was','upon','this','so','those','of','i','in','and','be','an','the','about','above','across','after','against','along','as','at','before','but','by','for','form','into','on'
preposition=set(prep)
while r:=file.readline():
    s=r.lower()
    words=s.split()
    uniqueword=set(words)
    p = uniqueword - preposition
    for i in p:
        if i in d.keys():
            c=words.count(i)
            d[i]+=c
        else:
            c=words.count(i)
            d[i]=c
for j in d.keys():
    file1.write("%s = %d\n"% (j,d[j]))
i=input("give the word ")
file=open("tamil bible.py","r")
while r:=file.readline():
    x=r.lower()
    s=x.split()
    if i in s:
        print(x,end='')

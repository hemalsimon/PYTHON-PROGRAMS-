# pr.no:18
#30/05/2020
#given integer no is even or odd

a=int(input("value of a "))
if a%2==0:
    print("even")
else:
    print ("odd")

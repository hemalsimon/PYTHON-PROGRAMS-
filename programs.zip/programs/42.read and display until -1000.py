#pr no 42
#01/06/2020
#read and display until -1000
a=int(input("value of a"))
while(a!=-1000):
    print(a)
    a = int(input("value of a"))

#pr no 61
#05/06/2020
#mean of ten numbers using while
i=1
c=0
while(i<=10):
    a=int(input("enter the numbers"))
    c=c+a
    i+=1
i=c/10
print(i)
#pr no 221
#26/07/2020
#extracton of name,age,city,pincode,phno,clg
import re
txt="Hemal  22  Dindigul    624709  8508967559  hemalsimontrichy@gmail.com"
d={}
d['name']=r'^[A-Z][a-z]+'
d['age']=r'\d{2}'
d['pincode']=r'\d{6}'
d['ph_no']=r'\d{10}'
d['mail']=r'[a-z]+[.a-z]+@[a-z]+.[a-z]+'
name=re.search(d['name'],txt)
age=re.search(d['age'],txt)
pincode=re.search(d['pincode'],txt)
ph_no=re.search(d['ph_no'],txt)
mail=re.search(d['mail'],txt)
print("name\t",n:=name.group())
print("age\t\t",a:=age.group())
print("pincode\t",pi:=pincode.group())
print("ph_no\t",p:=ph_no.group())
print("mail\t",m:=mail.group())
set1=set()
set1.update([n,a,pi,p,m])
set2=set()
split=txt.split()
set2.update(split)
set=set1^set2
print("city\t",set)
'''
s=set()
s1=set()
s.update([5,4,3])
s1.update([4,3])
s2=s1^s
print(s)
print(s1)
print(s2)
'''

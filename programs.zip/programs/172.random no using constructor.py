#pr no 172
#08/07/2020
#random no using constructor
import random
class mathprogram():
    def __init__(self,a=-100,b=100,c=10):
        self.__a=[]
        for i in range(c):
            n=random.randint(a,b)
            self.__a.append(n)
    def printrandom(self):
        b=1
        for i in self.__a:
            print(b,"random no=",i)
            b+=1
c=mathprogram()
c.printrandom()
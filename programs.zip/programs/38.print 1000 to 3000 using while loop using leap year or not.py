#pr no 38
#01/06/2020
#print the number 1000 to 3000 using while loop and check leap  or not
i=1000
while i<=3000:
    print(i)
    if(i%4==0):
        print("leap year")
    else:
        print("not a leap year")
    i+=1
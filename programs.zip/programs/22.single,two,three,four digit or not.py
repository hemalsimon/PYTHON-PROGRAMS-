# pr.no:22
#30/05/2020
#given integer no is two single,two,three,four digit or not

a=int(input("value of a "))
if a>=0 and a<=9:
    print("single digit")
elif a >= 10 and a <= 99:
        print("two digit")
elif a >= 100 and a <= 999:
    print("three digit")
elif a >= 1000 and a <= 9999:
    print("four digit")
else:
    print ("not a single,two,three,four digit")

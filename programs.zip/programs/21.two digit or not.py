# pr.no:21
#30/05/2020
#given integer no is two digit or not

a=int(input("value of a "))
if (a>=-99 and a<=-10) or (a>=10 and a<=99):
    print("two digit")
else:
    print ("not a two digit")

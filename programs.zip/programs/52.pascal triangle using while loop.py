#pr no 52
#02/06/2020
#pascal triangle using while loop
a=1
n=5
m=1
while (a<=6):
    b = 1
    while b<=n:
        print(" ",end=' ')
        b+=1
    c=1
    while c<=m:
            print("*",end=' ')
            c+=1
    print()
    a+=1
    n-=1
    m+=2

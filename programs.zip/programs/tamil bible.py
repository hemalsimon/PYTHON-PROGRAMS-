OLD TESTMENT.
BOOK OF GENESIS
In beginning and the of the beginning ;God created heaven, and earth.
2
And the earth was void and empty, and darkness was upon the face of the deep; and the
spirit of God moved over the waters.
3
And God said: Be light made. And light was made.
4
And God saw the light that it was good; and he divided the light from the darkness.
5
And he called the light Day, and the darkness Night and there was evening and morning one day.
6
And God said: Let there be a firmment made amidst the waters: and let it divide the waters from the waters.
7
And god made a firmament, and divided the waters that were under the firmament, from those that were above the firmament, and it was so.
8
And God called the firmament, Heaven; and the evening and morning were the second day.
9
God also said; Let the waters that are under the heaven,be gathered together into one place: and let the dry land appear. And it was so done.
10
And God called the dry land, Earth; and the gathering together of the waters, he called Seas. And God saw that it was good.
11
And he said: let the earth bring forth green herb, and such as may seed, and the fruit tree yielding fruit after its kind, which may have seed in itself upon the earth. And it was so done.
12
And the earth brought forth the green herb, and such as yieldeth seed according to its kind, and the tree that beareth fruit, having seed each one according to its kind. And God saw that it was good.
13
And the evening and the morning were the third day.
14
And God said: Let there be lights made in the firmament of heaven, to divide the day and the night, and let them be for signs, and for seasons, and for days and years:
15
To shine in the firmament of heaven, and to give light upon the earth, and it was so done.
16
And God made two great lights: a greater light to rule the day; and a lesser light to rule the night: and The stars.
17
And he set them in the firmament of heaven to shine upon the earth.
18
And to rule the day and the night, and to divide the light and the darkness. And God saw that it was good.
19
And the evening and morning were the fourth day.
20
God also said: let the waters bring forth the creeping creature having life, and the fowl that may fly over the earth under the firmament of heaven.
21
And God created the great whales, and every living and moving creature, which the waaters brought forth, according to their kinds, and every winged fowl according to its kind. And God saw that it was good. Book of Genesis
22
And he blessed them, saying: Increase and multiply, and fill the waters of them sea: and let the birds be multiplied upon the earth.
23
And the evening and morning were the fifth day.
24
And God said: Let the earth bring forth the living creature in its kind, cattle and creeping things, and beasts of the earth, according to their kinds. And it was so done.
25
And God made the beasts of the earth according to their kinds, and cattle, and every thing that creepeth on the earth after its kind. And God saw that it was good.
26
And he said: Let us make man to our image and likeness: and let him have dominion over the fishes of the sea, and the fowls of the air, and the beasts, and the whole earth, and every creeping creature that moveth upon the earth.
27
And God created man to his own image: to the image of God he created him: male and female he created them.
28
And God blessed them, saying: Increase and multiply, and fill the earth, and subdue it, and rule over the fishes of the sea, and the fowls of the air, and all living creatures that move upon the earth.
29
And God said: Behold I have given you every herb bearing seed upon the earth, and all trees that have in themselves seed of their own kind, to be your meat:
30
And to all beasts of the earth, and to every fowl of the air, and to all that move upon the earth, and wherein there is life, that they may have to feed upon. And it was so done.
31
And God saw all the things that he had made, and they were very good. And the evening and morning were the sixth day.


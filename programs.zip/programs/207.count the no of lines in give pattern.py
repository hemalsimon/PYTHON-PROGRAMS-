#pr no 207
#21/07/2020
#count the no of lines in given pattern
sourcefile=input("source file ")
search=input("which one do you want to search ")
f=open(sourcefile,"r")
r=f.readline()
count=0
while len(r):
    if r.find(search)!=-1:
       count+=1
    r=f.readline()
print(count)
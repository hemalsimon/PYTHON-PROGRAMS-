#pr no 93
#18/06/2020
#sum of the first and last column of the matrix
b=[]
i=0
while i<3:
    j=0
    a = []
    while j<3:
        x=int(input("value of x "))
        a.extend([x])
        j+=1
    b.append(a)
    print (i)
    i+=1
n=len(b)
i=0
while i<n:
    print(b[i])
    i+=1
print("")
n=len(b)
i=0
c=[]
while i<n:           
    sum=b[i][0]+b[i][2]
    c.append(sum)
    i+=1
print (c)
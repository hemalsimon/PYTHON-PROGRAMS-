#pr no 199
#20/07/2020
#read multiple lines
import sys
text=sys.stdin.readlines()
print(text)

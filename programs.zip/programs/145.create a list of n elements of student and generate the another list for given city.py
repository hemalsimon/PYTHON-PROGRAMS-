#pr no :143
#29/06/2020
#count the no of given the city
def records(n):
    b=[]
    for i in range (n):
        a=[]
        rollno=int(input("rollno "))
        name=(input("name "))
        age=int(input("age "))
        address=(input("address "))
        a.extend([rollno,name,age,address])
        b.append(a)
    return b
def generatelist(n,y,city):
    b=[]
    for i in range(n):
        if city in y[i]:
           b.append(y[i])
    return b
def printlist(x):
    n=len(x)
    for i in range(n):
        print(x[i])
n=int(input("give the range "))
y=records(n)
city=input("give the city")
x=generatelist(n,y,city)
printlist(x)
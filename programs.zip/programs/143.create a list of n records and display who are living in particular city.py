#pr no :143
#29/06/2020
#create a list of n records and display who are living in particular city
def records(n):
    b=[]
    for i in range (n):
        a=[]
        rollno=int(input("rollno "))
        name=(input("name "))
        age=int(input("age "))
        address=(input("address "))
        a.extend([rollno,name,age,address])
        b.append(a)
    return b
def particularcity(y,n,city):
    b=[]
    for i in range(n):
        a=[]
        if city in y[i]:
           a.append(y[i][1])
           b.append(a)
    return b
def printname(x):
    n=len(x)
    for i in range(n):
        print(x[i])
n=int(input("give the range "))
y=records(n)
city=input("give the city ")
x=particularcity(y,n,city)
printname(x)
#pr.no:122
#22/06/2020
#read the list in function and print it in second function pass the value to second function
def readlist():
    b=[]
    for i in range(10):
        x=int(input("x "))
        b.append(x)
    return b
def printlist(a):
    for i in range(10):
        print(a[i])
y=readlist()
printlist(y)
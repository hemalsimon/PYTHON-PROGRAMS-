#pr no 186
#16/07/2020
#arthimetic operation
from parent_points_184 import base_points
class arthimetic_operators(base_points):
    pass
    def __add__(self, nextpoint):
        p=self._x+nextpoint._x
        r=self._y+nextpoint._y
        return p,r
    def __sub__(self, nextpoint):
        p=self._x-nextpoint._x
        r=self._y-nextpoint._y
        return p,r
    def __mul__(self, nextpoint):
        p=self._x*nextpoint._x
        r=self._y*nextpoint._y
        return p,r
'''
#main
c=arthimetic_operators()
d=arthimetic_operators(50,100)
print(c)
print(d)
print("addition",c+d)
print("subraction",c-d)
print("multiplication",c*d)
'''

#pr no 146
#30/06/2020
#delete a record from the give key
def constructdictionary(n):
    c={}
    for i in range(n):
        a=[]
        rollno=int(input("rollno="))
        name=input("name ")
        age=int(input("age "))
        address=input("address ")
        a.extend([rollno,name,age,address])
        c[rollno]=a
    return c
def deleteparticularkey_and_print(x,key):
    del x[key]
    m=x.keys()
    print(m)
    for i  in m:
        print(x[i])
n=int(input("give the range "))
x=constructdictionary(n)
key=int(input("give the key "))
deleteparticularkey_and_print(x,key)
#pr no 146
#30/06/2020
#create a dictionary of n students in 1st function and print it in 2nd function
def constructdictionary(n):
    c={}
    for i in range(n):
        a=[]
        rollno=int(input("rollno="))
        name=input("name ")
        age=int(input("age "))
        address=input("address ")
        a.extend([rollno,name,age,address])
        c[rollno]=a
    return c
def printparticularkeys(x,key):
    m=x.keys()
    print(m)
    if key in m:
        print(x[key])
    else:
        print("invalid key")
n=int(input("give the range "))
x=constructdictionary(n)
key=int(input("give the key "))
printparticularkeys(x,key)
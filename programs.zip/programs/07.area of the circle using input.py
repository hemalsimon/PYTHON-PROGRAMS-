# pr.no:07
#30/05/2020
#area of the circle

r=int(input("value of r "))
c=3.14*r*r
print(c)
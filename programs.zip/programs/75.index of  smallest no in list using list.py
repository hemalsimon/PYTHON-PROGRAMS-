#pr no:69
#07/06/2020
# index of the smallest element in list using list
a=[]
x=int(input("value of x"))
while x!=1000:
    a.append(x)
    x=int(input("value of x"))
n=len(a)
i=0
b=a[0]
index=0
while i<n:
    if a[i]<b:
        b=a[i]
        index=i
    i+=1
print (b)
print (index,"index")
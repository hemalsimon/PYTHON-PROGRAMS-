#pr no 36
#01/06/2020
#print the number 1 to 100 using while loop and check even or odd
i=1
while i<=100:
    print(i)
    if(i%2==0):
        print("even")
    else:
        print ("odd")
    i+=1
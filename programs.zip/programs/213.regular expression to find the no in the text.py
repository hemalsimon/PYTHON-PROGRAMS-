import re
s="Ram 22 Hemal 23 Simon 6559 Sandy 545659 Kishore 654654 Ranjith 54646565"
x=re.findall('[A-Z][a-z]*',s)
y=re.findall('[6][0-9]*[9]',s)
z=re.findall('[5][0-9]*[9]',s)
print(x)
print(y)
print(z)
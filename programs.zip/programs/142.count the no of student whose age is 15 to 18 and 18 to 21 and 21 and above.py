#pr no :143
#29/06/2020
#create a list of n students with records
def records(n):
    b=[]
    for i in range (n):
        a=[]
        rollno=int(input("rollno "))
        name=(input("name "))
        age=int(input("age "))
        address=(input("address "))
        a.extend([rollno,name,age,address])
        b.append(a)
    return b
def count(y,n):
    fifteentoeighteen=0
    eighteentotwentyone=0
    twentyoneandabove=0
    for i in range(n):
        if y[i][2]>=15 and y[i][2]<18:
            fifteentoeighteen+=1
        elif y[i][2]>=18 and y[i][2]<21:
            eighteentotwentyone+=1
        elif y[i][2]>=21:
            twentyoneandabove+=1
    return fifteentoeighteen,eighteentotwentyone,twentyoneandabove
n=int(input("give the range "))
y=records(n)
print(count(y,n))
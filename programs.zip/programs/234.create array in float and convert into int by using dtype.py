import numpy as np
data=[[1.5,2.5,3.5],[4.5,5.5,6.5]]
con=np.array(data,dtype=int)
print(con)
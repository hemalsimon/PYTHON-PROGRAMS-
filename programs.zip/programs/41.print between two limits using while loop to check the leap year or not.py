#pr no 41
#01/06/2020
#print the between two limits using while loop to check the leap year or not
a=int(input("value of a"))
b=int(input("value of b"))
while(a<=b):
    if(a%4==0):
        print("leap year")
    else:
        print("not leap year")
    a+=1
    print(a)
#pr.no:114
#22/06/2020
#sum of the two no using default argument function
def sum(a=100,b=200):
    c=a+b
    return c
z=sum()
print(z)
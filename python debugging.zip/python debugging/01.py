def myfunction(a):
    a=a+2
        a=a*2
    return a
print(myfunction(2))

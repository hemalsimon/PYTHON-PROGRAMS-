a = [1,2,3,4,5]
b = a[::2]
#[start:stop:steps]
print(b)
print(a[::3])
print(a[::-1])
print(a[:])
print(a[3:])
print(a[:3])
print(a[-3:])
print(a[4::-2])



"""
for more details https://railsware.com/blog/python-for-machine-learning-indexing-and-slicing-for-lists-tuples-strings-and-other-sequential-types/
"""
x="stay safe stay healthy"
p=x[-2:-20:-5]
print(p)
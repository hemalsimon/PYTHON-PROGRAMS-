"""
which of the following statements is used to create a empty set?

a){ }
b)set()
c)[ ]
d)( )

"""
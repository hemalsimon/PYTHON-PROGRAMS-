"""
on assigning a value to a variable inside a function,it automatically becomes a global variable

a)true
b)false

"""
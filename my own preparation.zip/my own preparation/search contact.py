class dictionary():
    def __init__(self):
        self._a = {}
        for i in range(3):
            self._c = []
            name = input("name ")
            ph_no = int(input("ph no "))
            address = input("address ")
            nickname = input("nickname ")
            self._c.extend([name, ph_no, address, nickname])
            self._a[ph_no] = self._c
    def searchcontact(self):
        give = input("give the field")
        d=self._a.keys()
        for i in d:
            if give in d:
                print(self._a[i])
c=dictionary()
c.searchcontact()
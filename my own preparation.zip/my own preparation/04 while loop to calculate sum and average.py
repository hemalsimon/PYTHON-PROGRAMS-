#pr no 04
#sum and average using while loop
#03/02/2020
a=int(input("enter the no "))
sum=0
count=0
while a!=1000:
    sum=sum+a
    count=1+count
    a=int(input("enter the no "))
ave=sum/count
print("sum=",sum,"\nave=",int(ave))



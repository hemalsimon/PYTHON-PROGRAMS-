'''a=1
while a<6:
    print("* ",end='')
    a+=1
print("\n")
print("* "*5)

for a in range(6):
    print("*",end='')
'''
a=1
for a in range (11):
    c=a*3
    print(a," * 3=",c)
class test():
    def fn(self):
        print("god is love")
    def fn2(self):
        self.fn()
#main
a=test()
a.fn2()
print("* "*4)
i=1
while i<3:
    print("*")
    i+=1
print("* "*3)
i=1
while i<3:
    print("*")
    i+=1
print("* "*4)
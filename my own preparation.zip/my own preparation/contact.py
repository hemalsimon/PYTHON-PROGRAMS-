class dictionary():
    def __init__(self):
        self._a={}
        for i in range(3):
            self._c=[]
            name=input("name ")
            ph_no=int(input("ph no "))
            address=input("address ")
            nickname=input("nickname ")
            self._c.extend([name,ph_no,address,nickname])
            self._a[ph_no]=self._c

    def editcontact(self):
        contact=int(input("which contact do you want to edit"))
        d=self._a.keys()
        print("first",next(iter(self._a)))
        if contact in d:
            print("0 for name\n1 for phno\n2 for address\n3 for nickname ")
            a=int(input("which one do you delete"))
            if a==0:
                name=input("change the name ")
                self._a[contact][a]=name
            if a==1:
                ph_no=int(input("change the phno "))
                self._a[contact][a]=ph_no
                del list(self._a.keys())[0]
                print(self._a.keys())
                '''
                list(self._a.keys())[0]=ph_no'''
            if a==2:
                address=input("change the phno ")
                self._a[contact][a]=address
            if a==3:
                nickname=input("change the nick name ")
                self._a[contact][a]=nickname

    def print(self):
        d=self._a.keys()
        print("last",d)
        for i in d:
            print(self._a[i])
c=dictionary()
c.print()
c.editcontact()
c.print()
print(" *"*3)
b=1
while b<=2:
    print("*",end='')
    c = 1
    while c<=5:
       print("",end=' ')
       c+=1
    d=1
    while d<=1:
        print("*",end='\n')
        d += 1
    b+=1
print("* "*4)
b=1
c=1
while b<=3:
    print("*",end='')
    c = 1
    while c<=5:
        print(" ",end='')
        c+=1
    d=1
    while d<2:
        print("*",end="\n")
        d += 1
    b+=1
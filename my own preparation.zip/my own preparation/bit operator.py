a=int(input("a "))
print(a&1==1)
if a&1==1:

    print("odd")
else:
    print("even")
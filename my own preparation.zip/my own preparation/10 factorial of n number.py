#factorial of n nmber
#04/02/2021
#pr no 10
import math
no=int(input("enter the no "))
factorial=math.factorial(no)
print(factorial)

b=1
n=3
while b<=4:
    print(" *",end='')
    c = 1
    while c<=n:
        print(" ",end=' ')
        c+=1
    print("*")

    b+=1
    n-=1
b=1
n=1
while b<=3:
    print(" *",end='')
    c = 1
    while c<=n:
        print(" ",end=' ')
        c+=1
    print("*",end='\n')
    b+=1
    n+=1
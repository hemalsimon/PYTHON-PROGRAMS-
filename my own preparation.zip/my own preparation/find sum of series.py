#find the sum of series
a=1
sum=0
rang=int(input('enter the range '))
print("that series is")
for a in range(rang):
    if a%2!=0:
        print(a,end=' ')
        sum=sum+a
print("\nsum of that series=",sum)
#pr no 52
#02/06/2020
#pascal triangle using while loop
a=1
n=1
m=5
while (a<=6):
    c=1
    while c<=m:
            print("*",end=' ')
            c+=1
    b = 1
    while b <= n:
        print(" ", end=' ')
        b += 1
    print()
    a+=1
    n+=1
    m-=2

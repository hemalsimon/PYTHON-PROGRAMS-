#02/02/2021
#average OF N NUMBERS
#PR NO 02
i=1
sum=0
give_the_range=int(input("enter the range"))
while i <= give_the_range:
    sum=sum+i
    i+=1
ave=sum/give_the_range
print("aver of n numbers",int(ave))

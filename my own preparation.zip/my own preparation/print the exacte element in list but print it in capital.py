a=[]
x=(input("x "))
while x!='a':
    a.append(x)
    x=(input("x "))
a.sort()
print(sorted(a))
#fibonnacci seqence
#04/02/2021
#pr no 10
f=0
i=1
n=int(input("enter the range "))
a=0
while a<=n:
    a=f+i
    print(f,end=' ')
    f=i
    i=a

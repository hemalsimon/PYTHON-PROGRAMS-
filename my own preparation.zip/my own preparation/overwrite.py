b=[]
for i in range(3):
    a=[]
    name=input("name ")
    age=int(input("age"))
    address=input("address ")
    a.extend([name,age,address])
    b.append(a)
n=len(b[0])
print(n)
for i in b:
    print(i)
a=int(input("which column do you edit"))
name=input("name ")
age=int(input("age "))
address=input("address ")
b[a]=[name,age,address]
for i in b:
    print (i)
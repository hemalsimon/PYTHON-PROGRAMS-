a=1
while a<6:
    b=1
    while b<6:
        print("*",end=' ')
        b+=1
    print(" ")
    a+=1
for a in range(6):
    for b in range(6):
        print("* ",end='')
    print("")

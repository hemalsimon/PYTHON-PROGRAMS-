print("* "*4)
i=1
b=1
while i<2:
    print("*")
    i+=1
while b<=1:
    print("*",end='')
    c = 1
    while c<=5:
       print("",end=' ')
       c+=1
    print("* "*3)
    b+=1
g=1
while g<=1:
    print("*",end='')
    c = 1
    while c<=5:
       print("",end=' ')
       c+=1
    d=1
    while d<=1:
        print("*",end='')
        d += 1
    f=1
    while f<=3:
        print("",end=' ')
        f+=1
    e = 1
    while e <= 1:
        print("*", end='\n')
        e += 1
    g+=1
g=1
while g<=4:
    print("*",end=' ')
    g+=1
while f <= 5:
    print("", end=' ')
    f += 1
e = 1
while e <= 1:
    print("*", end='')
    e += 1

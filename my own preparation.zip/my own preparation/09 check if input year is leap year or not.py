#leap year or not
#04/02/2021
#pr no 09
year=int(input("enter the year="))
if year%4==0:
    print("given year is a leap year")
else:
    print("given year is not a leap year")
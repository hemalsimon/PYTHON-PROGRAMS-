#add two matrix
#pr no 11
#04/03/2021
import numpy as np
array1=np.array([[1,2],[3,4]])
array2=np.array([[5,6],[7,8]])
sum=array1+array2
multi=array1*array2
subtract=array1-array2
determinant_array1=np.linalg.det(array1)
determinant_array2=np.linalg.det(array2)
inverse=np.linalg.inv(array1)
print("sum\n",sum)
print("\nmulti\n",multi)
print("\nsubtract\n",subtract)
print("\ndeterminant_array1\n",determinant_array1)
print("\ndeterminant_array1\n",determinant_array2)
print("\ninverse\n",inverse)

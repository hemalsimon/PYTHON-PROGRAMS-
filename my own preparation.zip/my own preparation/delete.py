class dictionary():
    def __init__(self):
        self._a={}
        for i in range(3):
            self._c=[]
            name=input("name ")
            ph_no=int(input("ph no "))
            address=input("address ")
            nickname=input("nickname ")
            self._c.extend([name,ph_no,address,nickname])
            self._a[ph_no]=self._c
    def deletecontact(self):
        contact = int(input("which contact do you delete"))
        d=self._a.keys()
        print(d)
        if contact in d:
            print (self._a[contact][0],self._a[contact][1],self._a[contact][2],self._a[contact][3])
            del self._a[contact]
    def print(self):
            d=self._a.keys()
            print(d)
            for i in d:
                print(self._a[i])
c=dictionary()
c.deletecontact()
c.print()
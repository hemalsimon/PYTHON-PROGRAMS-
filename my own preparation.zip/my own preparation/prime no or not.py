a=int(input("give the range"))
i=1
while i<=a:
    j=1
    count=0
    while j<=i:
        if i%j==0:
            count=count+1
        j+=1
    if count <=2:
        print(i)
    i+=1
#02/02/2021
#SUM OF N NUMBERS
#PR NO 01
i=1
a=0
give_the_range=int(input("enter the range"))
while i <= give_the_range:
    a=a+i
    i+=1
print("sum of n numbers",a)
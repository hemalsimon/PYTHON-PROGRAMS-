a=1
n=5
m=1
while a<=6:
    b=1
    while b<=n:
        print(" ",end=' ')
        b+=1
    c=1
    while c<=m:
        print ("*",end=' ')
        c+=1
    print()
    n-=1
    a+=1
    m+=1



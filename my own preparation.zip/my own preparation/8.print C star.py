print(" *"*4)
i=1
while i<5:
    print("*")
    i+=1
print(" *"*4)
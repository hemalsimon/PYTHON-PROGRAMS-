print("\n *"*4)
print(" *"*3,end='')
data = {"Key1" : "Value1", "Key2" : "Value2"}
print(data.keys())
# output >>> dict_keys(['Key1', 'Key2'])
print(list(data.keys())[0])
# output >>> Key2
print(list(data.values())[1])
# output >>> Value2
from myparent import myParen
class Child( myParen ):
    def __init__( self ):
        myParen.__init__( self )

    def multiplyNumbers( self ):
        print (self.parentNumber )

p = Child()
p.multiplyNumbers()
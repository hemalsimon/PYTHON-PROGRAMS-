a=set()
for i in range(10):
    b=int(input("give the value"))
    a.add(b)
print(a)
for i in range(5):
    b=int(input("give the value"))
    a.update([b])
for i in a:
    print(i)

#pgm no:2
#30/06/20
#area of the circle

radius=4
area=3.14*radius*radius
print(area)
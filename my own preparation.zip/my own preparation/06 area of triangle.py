#area of triangle
#04/02/2021
#pr no 06
base=int(input("enter the base length="))
height=int(input("enter the height length="))
area=0.5*base*height
print("area of triangle is=",area)
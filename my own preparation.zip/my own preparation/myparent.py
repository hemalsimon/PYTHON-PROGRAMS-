class myParen( object ):
    def __init__( self ):
        self.parentNumber = 5

#solve quadratic equation
#04/02/2021
#pr no 07
import numpy as np
quadratic = [1,8,12]
print(np.roots(quadratic))
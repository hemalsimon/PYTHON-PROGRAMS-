#include<stdio.h>
main()
{
	int n,c;
	scanf("%d",&n);
	if(n&1 == 1)
		printf("%d given number is  ODD",n);
	else

		printf("%d given number is EVEN",n);
}

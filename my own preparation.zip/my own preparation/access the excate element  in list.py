a=[]
x=int(input("x "))
while x!=1000:
    a.append(x)
    x=int(input("x "))
i=int(input("key the index"))
print(a[i])
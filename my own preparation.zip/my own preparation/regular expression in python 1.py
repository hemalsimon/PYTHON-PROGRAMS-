import re
print("1",re.search('n','\n'))
print("2",re.search('n','\\n'))
print("3",re.search('n','\n\n\n\n\n\n\n\n\n'))
print("4",re.search('n',r'\n\n\n\n\n\n\n\n\n'))
print("5",re.search('\n','\n\n\n\n\n\n\n\n\n'))
print("6",re.search('\n',r'\n\n\n\n\n\n\n\n\n'))
print("7",re.search(r'\n','\n\n\n\n\n\n\n\n\n'))
print("8",re.search(r'\n',r'\n\n\n\n\n\n\n\n\n'))
print("9",re.search('^l','hello'))
print("10",re.search('^h','hello'))
print("11",re.search('l','hello'))  #here this search the  first occerence of the l not the second occurence
print("12",re.match('^l','hello'))
print("13",re.match('^h','hello'))
print("14",re.match('l','hello'))
print("15",re.search('le','hello')) #it doesn't check because the leading l with e is not there so it's can't
print("16",re.search('l|e','hello'))    #which one first occur that will search
print("17",re.search('h|e','hello'))    #which one first occur that will search
print("17",re.search('h|e','hello').group())    #using .group function is print the exact value not like this <re.Match object; span=(0, 1), match='h'> like this 'h'
print("18",re.findall('l|h','hellohello'))   #here we doesn't use the .group function for findall
print("19",re.search('ello','hellohello').group())  #search is used for search in first occurence
print("20",re.findall('ello','hello,hello'))        #findall is used to find where and how many times it is comes
print("21",re.search('\w','hello').group())         #search by using \w this take only one character of a word and this is the alpha numeric that is [a-zA-Z0-9 and _]
print("22",re.search('\w\w\w','he_llo').group())     #if you give the \w for twice or thrice that take two or three character    and this the alpha numeric that is [a-zA-Z0-9 and _]
print("23",re.search('\w{3}','_845621').group())      # \w{3} it take the fixed three character  and this the alpha numeric that is [a-zA-Z0-9 and _]
print("24",re.search('\W','856 !-.').group())  #\W backslash capital W is used for search or find the ! or - or . or blankspaces

#quantifiers
'''
+=1 or more
*=0 or more
?=0 or 1
{n,m}=n to m repetitions    {,3} {3,}   first curly brazes is befor 3 no, second curly brazes is after 3 
'''

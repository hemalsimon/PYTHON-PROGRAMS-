a=1
rang=int(input("enter the no "))
while a<=rang:
    print(a,"*5",a*5)
    a+=1
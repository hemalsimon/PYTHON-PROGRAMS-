#convert celsius to fahrenheit
#04/02/2021
#pr no 08
c=float(input("enter the celsius"))
farhren=(c * (9/5))+ 32
print(farhren,"F")
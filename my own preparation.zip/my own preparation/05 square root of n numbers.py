#square root of n numbers
#pr no 5
#30/02/2021
import math
a=int(input("enter the no"))
b=[]
while a!=1000:
    i=math.sqrt(a)
    b.append(i)
    a = int(input("enter the no"))
print(b)


#pgm no:1
#30/06/20
#product of two real numbers

a=2.5
b=3.5
c=a*b
print(c)
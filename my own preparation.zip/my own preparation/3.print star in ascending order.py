a=1
n=1
while a<6:
    b=1
    while b<n:

        print("*",end=' ')
        b+=1
    n+=1
    a+=1
    print(" ")
    '''
n=1
for a in range(6):
    for b in range():
        print("*",end='')
        n+=1
    print("")'''


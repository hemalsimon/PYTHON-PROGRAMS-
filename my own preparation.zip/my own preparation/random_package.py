#pr no 172
#08/07/2020
#random no using constructor
import random
class mathprogram():
    def __init__(self):
        self.__d=[]
        for i in range(20):
            n=random.randint(-100,100)
            self.__j=self.__d.append(n)
    def printrandom(self):
        b=1
        for i in self.__d:
            print(b,"random no=",i)
            b+=1
    def poscount(self):
        poscount=0
        for i in self.__d:
            if i >0:
                poscount+=1
        return poscount
    def negcount(self):
        negcount=0
        for i in self.__d:
            if i <0:
                negcount+=1
        return negcount
    def zerocount(self):
        zerocount=0
        for i in self.__d:
            if i ==0:
                zerocount+=1
        return zerocount
    def possum(self):
        possum=0
        for i in self.__d:
            if i>0:
                possum=possum+i
        return possum
    def negsum(self):
        negsum=0
        for i in self.__d:
            if i<0:
                negsum=negsum+i
        return negsum
    def biggest(self):
        big=self.__d[0]
        for i in self.__d:
            big=i if i>big else big
        return big
    def smallest(self):
        small=self.__d[0]
        for i in self.__d:
            small=i if i<small else small
        return small
    def noeven(self):
        noeven=0
        for i in self.__d:
            n=i%2==0
            if(not n):
                noeven+=1
        return noeven
    def noodd(self):
        noodd=0
        for i in self.__d:
            n=i%2==0
            if(n):
                noodd+=1
        return noodd
    def possep(self):
        self.__a=[]
        n=len(self.__d)
        m=int(n/2)
        print(m)
        for i in range(n):
            if self.__d[i]>0:
                self.__a.append(self.__d[i])
        return self.__a
    def negsep(self):
        self.__a=[]
        n=len(self.__d)
        m=int(n/2)
        print(m)
        for i in range(n):
            if self.__d[i]<0:
                self.__a.append(self.__d[i])
        return self.__a
    def firsthalf(self):
        self.__a=[]
        n=len(self.__d)
        m=int(n/2)
        for i in range(m):
            self.__a.append(self.__d[i])
        return self.__a
    def secondhalf(self):
        self.__a=[]
        n=len(self.__d)
        m=int(n/2)
        while n!=m:
            self.__a.append(self.__d[m])
            n+=1
        return self.__a
c=mathprogram()
c.printrandom()
print("\n")
print("positive count ",c.poscount())
print("negative count ",c.negcount())
print("positive sum ",c.possum())
print("negative sum ",c.negsum())
print("biggest no ",c.biggest())
print("smallest no ",c.smallest())
print("no of even ",c.noeven())
print("no of odd ",c.noodd())
print(c.possep())
print(c.negsep())
print(c.firsthalf())
print(c.secondhalf())
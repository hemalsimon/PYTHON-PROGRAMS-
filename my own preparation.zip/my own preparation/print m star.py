print("*")
b=1
n=1
m=5
while b<=2:
    print("*",end='')
    c = 1
    while c<=n:
        print("",end=' ')
        c+=1
    print("*", end='\n')
    a = 1
    while a <= m:
        print("*", end=' ')
        a += 1
    b+=1
    n+=1
    m-=2
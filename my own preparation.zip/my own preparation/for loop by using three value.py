for i in range(1000,101):
    #for i in range (i=0,i<101,i+=10)
    print(i)
for i in range(1000,101):
    #for i in range(i=0,i<101)  its automatically add one increment
    print(i)


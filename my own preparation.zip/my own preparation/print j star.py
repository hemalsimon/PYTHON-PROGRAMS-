print("* "*5)
b=1
while b<=2:
    c = 1
    while c<=4:
        print("",end=' ')
        c+=1
    d=1
    while d<=1:
        print("*",end='\n')
        d += 1
    b+=1
b=1
while b<=1:
    e=1
    while e<=1:
        print("*",end='')
        e += 1
    c = 1
    while c<=3:
        print("",end=' ')
        c+=1
    d=1
    while d<=1:
        print("*",end='\n')
        d += 1
    b+=1
print(" *"*2)
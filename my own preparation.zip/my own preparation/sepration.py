from random_package import mathprogram
class sepration(mathprogram):
    def __init__(self):
        mathprogram.__init__(self)
    def positivesep(self):
        self.__x=[]
        for i in self.__j:
            if i >0:
                self.__x.append(i)
        return self.__x
y=sepration()
y.printrandom()
print("\n")
print("positive count ",y.poscount())
print("negative count ",y.negcount())
print("positive sum ",y.possum())
print("negative sum ",y.negsum())
print("biggest no ",y.biggest())
print("smallest no ",y.smallest())
print("no of even ",y.noeven())
print("no of odd ",y.noodd())
print("positive sepration",y.positivesep())
            
            
        
#pr no 03
#sum and average of given list of number
#02/02/2021
a=[1,2,3,4,5,6,7,8,9,10]
sum=0
for i in a:
    sum=sum+i
ave=sum/len(a)
print("sum for given list",sum,"\nave of given no",int(ave))
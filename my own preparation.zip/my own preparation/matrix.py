#pr no 82
#12/06/2020
#create 3 x 3 matrix print it row by row
b=[]
i=0
while i<4:
    a = []
    j=0
    while j<3:
        x=int(input("value of x"))
        a.append(x)
        j+=1
    b.append(a)
    i+=1
n=len(b)
c=len(b[0])
print(c)
print(n)
i=0
while i<n:
    print(b[i])
    i+=1
for i in range(n) :
    n=len(b[i])
print(n)

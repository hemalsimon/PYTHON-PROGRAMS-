#pgm no:72
#18/07/20
#construct a list of elements and find its biggest and smallest and its position

x=[]
a=int(input())
while a!=1000:
    x.append(a)
    a=int(input())
n=len(x)
i=0
big=x[0]
small=x[0]
bigposition=0
smallposition=0
while i<n:
    print(x[i])
    if x[i]>big:
           big=x[i]
           bigposition=i
    elif x[i]<small:
        small=x[i]
        smallposition=i
    i=i+1
print("big",big)
print("big position",bigposition)
print("small",small)
print("small position",smallposition)
x[bigposition]=small
x[smallposition]=big
i=0
print("after interchange")
while i<n:
    print(x[i])
    i=i+1

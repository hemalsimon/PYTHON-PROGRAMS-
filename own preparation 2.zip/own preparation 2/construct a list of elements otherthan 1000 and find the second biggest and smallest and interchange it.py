#pgm no:75
#24/07/20
#construct a list of elements otherthan1000 and find the second biggest and smallest and interchange it

x=[]
a=int(input())
while a!=1000:
    x.append(a)
    a=int(input())
n=len(x)
i=0
firstbig=x[0]
firstsmall=x[0]
firstbigposition=0
firstsmallposition=0
while i<n:
    print(x[i])
    if x[i]>firstbig:
        firstbig=x[i]
        firstbigposition=i
    elif x[i]<firstsmall:
        firstsmall=x[i]
        firstsmallposition=i
    i=i+1
print("firstbig",firstbig)
print("firstsmall",firstsmall)
print("firstbigposition",firstbigposition)
print("firstsmallposition",firstsmallposition)
i=0
secondbig=-x[0]
secondbigposition=0
while i<n:
    print(x[i])
    if x[i]!=firstbig:
        if x[i]>secondbig:
            secondbig=x[i]
            secondbigposition=i
    i=i+1
print("secondbig",secondbig)
print("secondbigposition",secondbigposition)
i=0
secondsmall=x[0]
secondsmallposition=0
while i<n:
    print(x[i])
    if x[i]!=firstsmall:
        if x[i]<secondsmall:
            secondsmall=x[i]
            secondsmallposition=i
    i=i+1
print("secondsmall",secondsmall)
print("secondsmallposition",secondsmallposition)
x[secondbigposition]=secondsmall
x[secondsmallposition]=secondbig
print("after interchange")
i=0
while i<n:
    print(x[i])
    i=i+1

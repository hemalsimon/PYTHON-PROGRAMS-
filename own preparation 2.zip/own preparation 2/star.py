#program no.51
#21/7/10
#star2
i=0
j=0
n=6
while i<6:
    j=0
    while j<n:
     print("*",end="")
     j=j+1
    print(" ")
    i=i+1
    n=n-1

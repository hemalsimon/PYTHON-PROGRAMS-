#pgm no:71
#18/07/20
#construct a list of elements and find its biggest and position

x=[]
a=int(input())
while a!=1000:
    x.append(a)
    a=int(input())
n=len(x)
i=0
d=x[0]
index=0
while i<n:
    print(x[i])
    if x[i]>d:
        d=x[i]
        index=i
    i=i+1
print("big",d)
print("position",index)



#pgm no:69
#15/07/20
#construct a list of elements otherthan1000 and print the average

x=[]
a=int(input())
while a!=1000:
    x.append(a)
    a=int(input())
n=len(x)
i=0
b=0
while i<n:
    b=b+x[i]
    i=i+1
e=b/n
print(e)
#pgm no:70
#17/07/20
#construct a list of element otherthan 1000 and print the smallest

x=[]
a=int(input())
while a!=1000:
    x.append(a)
    a=int(input())
n=len(x)
i=0
while i>n:
    print(x[i])
    d=0
    if x[i]<d:
        d=x[i]
    i=i+1
print(d)


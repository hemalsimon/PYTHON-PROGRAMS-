#pgm no:68
#15/07/20
#construct a list of elements otherthan1000 and print it element by element

x=[]
a=int(input())
while a!=1000:
    x.append(a)
    a=int(input())
n=len(x)
i=0
while i<n:
    print (x[i])
    i=i+1
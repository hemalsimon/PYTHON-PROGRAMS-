#pgm no:
#17/07/20
#construct a list of element otherthan 1000 and print the average

x=[]
a=int(input())
while a!=1000:
    x.append(a)
    a=int(input())
n=len(x)
i=0
firstbig=x[0]
while i<n:
    print (x[i])
    if x[i]>firstbig:
         firstbig=x[i]
    i+=1
print("firstbig",firstbig)
i=0
secondbig=-x[0]
while i<n:
    print(x[i])
    if x[i]!=firstbig:
         if x[i]>secondbig:
                secondbig=x[i]
    i+=1
print("secondbig",secondbig)


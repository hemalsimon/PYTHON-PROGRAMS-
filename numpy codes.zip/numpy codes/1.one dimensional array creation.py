import numpy as np
a=[45,8,69,21,35,5]
one_array=np.array(a,ndmin=3,2)
x=1
y=1
while s<15:
    fact=x+y
    print(fact)
    s+=1
